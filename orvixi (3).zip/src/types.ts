export type Language = 'en' | 'hi' | 'mr';

export type PriorityLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type ApprovalCategory = 'required' | 'conditional' | 'recommended' | 'optional';

export type ApprovalStatus = 'completed' | 'pending' | 'in_progress' | 'blocked';

export interface BusinessProfile {
  id: string;
  name: string;
  type: string;
  industry: string;
  location: string;
  state: string;
  size: 'Micro' | 'Small' | 'Medium' | 'Large Enterprise';
  investment: string;
  employees: number;
  activities: string[];
  products: string[];
  startDate: string;
  riskProfile: 'LOW' | 'MODERATE' | 'HIGH';
  category: string;
  gstin: string;
  pan: string;
}

export interface ApprovalItem {
  id: string;
  name: string;
  authority: string;
  department: string;
  category: ApprovalCategory;
  purpose: string;
  eligibility: string;
  requiredDocuments: string[];
  estimatedProcessingTimeDays: number;
  priority: PriorityLevel;
  status: ApprovalStatus;
  dependencies: string[]; // ids of other approvals
  renewalRequirement: string;
  feeEstimate: string;
  portalUrl: string;
  stage: number;
  simpleExplanation?: string;
  simpleExplanationHi?: string;
  simpleExplanationMr?: string;
}

export interface DocumentItem {
  id: string;
  name: string;
  category: string;
  fileType: 'PDF' | 'JPG' | 'PNG' | 'DOCX';
  fileSize: string;
  uploadDate: string;
  expiryDate: string;
  status: 'verified' | 'needs_attention' | 'expired' | 'processing';
  healthScore: number;
  matchedFields: {
    field: string;
    value: string;
    status: 'match' | 'mismatch' | 'missing';
  }[];
  issues: string[];
  linkedApprovalId?: string;
}

export interface ComplianceItem {
  id: string;
  title: string;
  category: string;
  dueDate: string;
  daysRemaining: number;
  status: 'on_track' | 'upcoming' | 'overdue' | 'warning';
  risk: PriorityLevel;
  description: string;
  statutoryAct: string;
  actionText: string;
  penaltyClause: string;
}

export interface SchemeItem {
  id: string;
  name: string;
  department: string;
  ministry: string;
  benefitType: 'Subsidy' | 'Grant' | 'Tax Incentive' | 'Low-Interest Loan' | 'Incentive';
  benefitAmount: string;
  eligibilityScore: number;
  deadline: string;
  eligible: boolean;
  requiredDocuments: string[];
  matchedCriteria: string[];
  missingCriteria: string[];
  description: string;
  portalLink: string;
}

export interface WorkspaceTask {
  id: string;
  title: string;
  priority: PriorityLevel;
  deadline: string;
  dueDate?: string;
  daysLeft: number;
  completed: boolean;
  category: string;
  reason: string;
  description?: string;
  source: 'ai_detected' | 'user' | 'compliance' | 'approval';
  isAiDetected?: boolean;
  actionText: string;
  linkedApprovalId?: string;
}

export interface IdeaProject {
  id: string;
  title: string;
  tagline: string;
  problem: string;
  solution: string;
  targetUsers: string[];
  keyFeatures: string[];
  businessModel: string;
  requiredApprovals: string[];
  governmentSchemes: string[];
  roadmap: string[];
  riskMitigation: string;
  createdAt: string;
  status: 'concept' | 'improvising' | 'validated';
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'jarvis';
  text: string;
  timestamp: string;
  language?: Language;
  simplifiedText?: string;
  actionSuggestion?: {
    label: string;
    view: string;
    tab?: string;
  };
}

export type UserRole =
  | 'Founder / Business Owner'
  | 'Compliance Officer'
  | 'Legal Consultant'
  | 'Plant Manager'
  | 'Individual Contractor';

export interface UserWorkflow {
  id: string;
  title: string;
  description: string;
  targetView: AppView;
  status: 'in_progress' | 'pending' | 'completed';
  progressPercent: number;
  pendingTasksCount: number;
  badgeText: string;
}

export interface UserAccount {
  id: string;
  fullName: string;
  email: string;
  phone: string;
  role: UserRole;
  designation: string;
  panNumber: string;
  aadhaarLastFour: string;
  companyName: string;
  isLoggedIn: boolean;
  avatarUrl?: string;
  assignedWorkflows: UserWorkflow[];
}

export type AppView =
  | 'landing'
  | 'dashboard'
  | 'business-profile'
  | 'approval-mapper'
  | 'document-validator'
  | 'approval-workflow'
  | 'compliance'
  | 'government-schemes'
  | 'my-orvixi'
  | 'idea-lab'
  | 'jarvis'
  | 'reports'
  | 'security'
  | 'auth-portal'
  | 'settings';
