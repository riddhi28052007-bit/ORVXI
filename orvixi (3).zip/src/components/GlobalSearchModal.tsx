import React, { useState, useEffect, useRef } from 'react';
import { Search, X, Layers, FileText, Award, CheckSquare, Lightbulb, AlertTriangle, ArrowRight } from 'lucide-react';
import { DEMO_APPROVALS, DEMO_DOCUMENTS, DEMO_SCHEMES, DEMO_AI_TASKS, DEMO_IDEAS } from '../data/demoData';
import { AppView, ApprovalItem, SchemeItem, Language } from '../types';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (view: AppView) => void;
  approvals?: ApprovalItem[];
  schemes?: SchemeItem[];
  language?: Language;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  onNavigate,
  approvals,
  schemes,
  language = 'en'
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else onClose(); // parent handles toggle
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const q = query.toLowerCase().trim();

  // Search results
  const approvalList = approvals && approvals.length > 0 ? approvals : DEMO_APPROVALS;
  const filteredApprovals = q
    ? approvalList.filter(
        (a) =>
          (a.name || '').toLowerCase().includes(q) ||
          (a.authority || '').toLowerCase().includes(q) ||
          (a.purpose || '').toLowerCase().includes(q)
      )
    : approvalList.slice(0, 3);

  const filteredDocs = q
    ? DEMO_DOCUMENTS.filter(
        (d) =>
          (d.name || '').toLowerCase().includes(q) ||
          (d.category || '').toLowerCase().includes(q) ||
          (d.issues || []).some((i) => (i || '').toLowerCase().includes(q))
      )
    : DEMO_DOCUMENTS.slice(0, 2);

  const schemeList = schemes && schemes.length > 0 ? schemes : DEMO_SCHEMES;
  const filteredSchemes = q
    ? schemeList.filter(
        (s) =>
          (s.name || '').toLowerCase().includes(q) ||
          (s.department || '').toLowerCase().includes(q) ||
          (s.benefitType || '').toLowerCase().includes(q)
      )
    : schemeList.slice(0, 2);

  const filteredTasks = q
    ? DEMO_AI_TASKS.filter(
        (t) =>
          t.title.toLowerCase().includes(q) ||
          t.reason.toLowerCase().includes(q) ||
          t.category.toLowerCase().includes(q)
      )
    : DEMO_AI_TASKS.slice(0, 2);

  const filteredIdeas = q
    ? DEMO_IDEAS.filter(
        (i) =>
          i.title.toLowerCase().includes(q) ||
          i.tagline.toLowerCase().includes(q) ||
          i.solution.toLowerCase().includes(q)
      )
    : [];

  const handleSelect = (view: AppView) => {
    onNavigate(view);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-150"
      onClick={onClose}
      id="global-search-modal-backdrop"
    >
      <div
        className="w-full max-w-2xl rounded-2xl bg-slate-900 border border-slate-700/80 shadow-2xl shadow-cyan-950/50 overflow-hidden flex flex-col max-h-[80vh] animate-in zoom-in-95 duration-150"
        onClick={(e) => e.stopPropagation()}
        id="global-search-modal"
      >
        {/* Search Input Bar */}
        <div className="flex items-center px-4 py-3.5 border-b border-slate-800 gap-3">
          <Search className="w-5 h-5 text-cyan-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search approvals, documents, schemes, tasks, or ask ORVIXI..."
            className="flex-1 bg-transparent text-white placeholder-slate-400 text-sm focus:outline-none"
            id="global-search-input"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-slate-400 hover:text-white rounded"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <kbd className="px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-[10px] font-mono text-slate-400">
            ESC
          </kbd>
        </div>

        {/* Quick query chips */}
        <div className="px-4 py-2 border-b border-slate-800/60 flex items-center gap-1.5 overflow-x-auto text-[11px] text-slate-400">
          <span className="shrink-0 font-medium">Quick suggestions:</span>
          {['Factory License', 'Address Mismatch', 'PLI Scheme', 'Hazardous Waste', 'Solar PV'].map(
            (tag) => (
              <button
                key={tag}
                type="button"
                onClick={() => setQuery(tag)}
                className="px-2.5 py-0.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors shrink-0"
              >
                {tag}
              </button>
            )
          )}
        </div>

        {/* Results Container */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Approvals */}
          {filteredApprovals.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">
                <Layers className="w-3.5 h-3.5 text-cyan-400" />
                <span>Approvals & Statutory Permissions</span>
              </div>
              <div className="space-y-1.5">
                {filteredApprovals.map((app) => (
                  <button
                    key={app.id}
                    onClick={() => handleSelect('approval-mapper')}
                    className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-800 text-left transition-colors group cursor-pointer"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-white group-hover:text-cyan-300 transition-colors">
                          {app.name}
                        </span>
                        <span
                          className={`text-[9px] px-1.5 py-0.2 rounded font-mono uppercase ${
                            app.status === 'completed'
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : app.status === 'blocked'
                              ? 'bg-rose-500/20 text-rose-400'
                              : 'bg-amber-500/20 text-amber-400'
                          }`}
                        >
                          {app.status}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                        {app.authority} • {app.purpose}
                      </p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-cyan-400 shrink-0 group-hover:translate-x-1 transition-all" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Documents */}
          {filteredDocs.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">
                <FileText className="w-3.5 h-3.5 text-indigo-400" />
                <span>Documents & OCR Dossiers</span>
              </div>
              <div className="space-y-1.5">
                {filteredDocs.map((doc) => (
                  <button
                    key={doc.id}
                    onClick={() => handleSelect('document-validator')}
                    className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-800 text-left transition-colors group cursor-pointer"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-white group-hover:text-indigo-300 transition-colors">
                          {doc.name}
                        </span>
                        <span className="text-[9px] px-1.5 py-0.2 rounded font-mono bg-slate-800 text-slate-300">
                          {doc.healthScore}% Health
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                        {doc.issues.length > 0 ? (
                          <span className="text-amber-400">⚠ {doc.issues[0]}</span>
                        ) : (
                          'All fields verified with MCA & MIDC records.'
                        )}
                      </p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-indigo-400 shrink-0 group-hover:translate-x-1 transition-all" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Government Schemes */}
          {filteredSchemes.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">
                <Award className="w-3.5 h-3.5 text-emerald-400" />
                <span>Government Schemes & Incentives</span>
              </div>
              <div className="space-y-1.5">
                {filteredSchemes.map((sch) => (
                  <button
                    key={sch.id}
                    onClick={() => handleSelect('government-schemes')}
                    className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-800 text-left transition-colors group cursor-pointer"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-white group-hover:text-emerald-300 transition-colors">
                          {sch.name}
                        </span>
                        <span className="text-[9px] px-1.5 py-0.2 rounded font-mono bg-emerald-500/20 text-emerald-400">
                          {sch.eligibilityScore}% Match
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                        {sch.benefitAmount} • {sch.ministry}
                      </p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-emerald-400 shrink-0 group-hover:translate-x-1 transition-all" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Tasks */}
          {filteredTasks.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">
                <CheckSquare className="w-3.5 h-3.5 text-amber-400" />
                <span>AI Detected Tasks</span>
              </div>
              <div className="space-y-1.5">
                {filteredTasks.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => handleSelect('my-orvixi')}
                    className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-800 text-left transition-colors group cursor-pointer"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-white group-hover:text-amber-300 transition-colors">
                          {t.title}
                        </span>
                        <span className="text-[9px] px-1.5 py-0.2 rounded font-mono bg-rose-500/20 text-rose-400">
                          {t.priority}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                        {t.reason}
                      </p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-amber-400 shrink-0 group-hover:translate-x-1 transition-all" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Ideas */}
          {filteredIdeas.length > 0 && (
            <div>
              <div className="flex items-center gap-2 mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">
                <Lightbulb className="w-3.5 h-3.5 text-yellow-400" />
                <span>AI Idea Lab Projects</span>
              </div>
              <div className="space-y-1.5">
                {filteredIdeas.map((idea) => (
                  <button
                    key={idea.id}
                    onClick={() => handleSelect('idea-lab')}
                    className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-850 hover:bg-slate-800 border border-slate-800 text-left transition-colors group cursor-pointer"
                  >
                    <div>
                      <span className="text-xs font-semibold text-white group-hover:text-yellow-300 transition-colors">
                        {idea.title}
                      </span>
                      <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">
                        {idea.tagline}
                      </p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-yellow-400 shrink-0 group-hover:translate-x-1 transition-all" />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-4 py-2.5 bg-slate-950 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-500">
          <span>ORVIXI Intelligent Search Engine</span>
          <span>Tip: Press ESC to close</span>
        </div>
      </div>
    </div>
  );
};
