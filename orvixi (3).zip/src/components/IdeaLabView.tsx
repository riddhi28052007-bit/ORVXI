import React, { useState } from 'react';
import {
  Lightbulb,
  Sparkles,
  TrendingUp,
  ShieldCheck,
  Target,
  IndianRupee,
  Layers,
  ArrowRight,
  Bookmark,
  CheckCircle2,
  RefreshCw,
  Zap,
  HelpCircle
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Language } from '../types';
import { TRANSLATIONS } from '../data/demoData';

interface IdeaLabViewProps {
  language: Language;
}

export const IdeaLabView: React.FC<IdeaLabViewProps> = ({ language }) => {
  const [ideaText, setIdeaText] = useState(
    'Recycling discarded EV lithium batteries into stationary energy storage packs for agricultural solar micro-grids in rural Maharashtra.'
  );
  const [industry, setIndustry] = useState('Clean Tech & Energy Storage');
  const [targetCustomer, setTargetCustomer] = useState('Rural Farmers & Solar Cooperatives');
  const [budget, setBudget] = useState('₹1.5 Crores');
  const [location, setLocation] = useState('Pune / Nashik Industrial Corridor, Maharashtra');
  const [isGenerating, setIsGenerating] = useState(false);
  const [activeTab, setActiveTab] = useState<'improvements' | 'monetization' | 'regulatory' | 'growth'>('improvements');
  const [savedCount, setSavedCount] = useState(12);
  const [isSaved, setIsSaved] = useState(false);

  const [aiResult, setAiResult] = useState({
    improvements: [
      'Implement modular BMS (Battery Management System) with IoT telematics to monitor state-of-health remotely.',
      'Adopt a Battery-as-a-Service (BaaS) subscription model for agricultural cold storages to lower upfront capex for farmer collectives.',
      'Integrate automated disassembly robotic jigs to cut manual dismantling hazards by 80%.'
    ],
    monetization: [
      'Upfront hardware lease with annual performance warranty (₹1.8L - ₹3.5L per 15kWh pack).',
      'Recurring software telemetry subscription (₹1,200/month/site) for predictive replacement.',
      'Carbon credit issuance under Article 6 of Paris Agreement for avoided diesel generator usage.'
    ],
    regulatory: [
      'CPCB Extended Producer Responsibility (EPR) Registration for Battery Waste Management Rules 2022.',
      'MPCB Hazardous Waste Authorization (Schedule 1, Category 33.1).',
      'BIS CRS certification under IS 16046 (Secondary cells and batteries containing alkaline or other non-acid electrolytes).'
    ],
    growth: [
      'Partner with Maharashtra State Electricity Distribution Company (MSEDCL) for rural feeder solarization pilot.',
      'Apply for NABARD Agri-Infra Fund 3% interest subvention loan up to ₹2 Crores.'
    ]
  });

  const handleImproveIdea = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ideaText.trim()) return;

    setIsGenerating(true);
    setIsSaved(false);

    try {
      const res = await fetch('/api/ai/improve-idea', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          idea: ideaText,
          industry,
          targetCustomer,
          budget,
          location,
          language
        })
      });

      if (res.ok) {
        const data = await res.json();
        setAiResult({
          improvements: data.improvements || aiResult.improvements,
          monetization: data.monetization || aiResult.monetization,
          regulatory: data.regulatory || aiResult.regulatory,
          growth: data.growth || aiResult.growth
        });
      }
    } catch (err) {
      console.error('AI synthesis fallback engaged:', err);
    } finally {
      setIsGenerating(false);
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
    }
  };

  const handleSaveIdea = () => {
    if (!isSaved) {
      setIsSaved(true);
      setSavedCount((c) => c + 1);
      confetti({ particleCount: 40, spread: 50 });
    }
  };

  return (
    <div className="space-y-8 pb-16 animate-in fade-in duration-200" id="orvixi-idea-lab-view">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/80 border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 font-mono">
              CORE FEATURE // SECTION 15
            </span>
            <span className="text-xs text-slate-400 font-mono">{savedCount} Saved Ideas</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-display text-white">
            ORVIXI Idea Lab • Business Improviser
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Explore, stress-test, monetize, and synthesize regulatory pathways for emerging business ventures
          </p>
        </div>

        <button
          onClick={handleSaveIdea}
          className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
            isSaved
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
              : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
          }`}
        >
          <Bookmark className="w-4 h-4" />
          <span>{isSaved ? 'Idea Saved in Lab' : 'Save this Idea'}</span>
        </button>
      </div>

      {/* IDEA INPUT FORM */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 space-y-6">
        <form onSubmit={handleImproveIdea} className="space-y-5">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              Describe Your Raw Business Idea *
            </label>
            <textarea
              rows={3}
              required
              value={ideaText}
              onChange={(e) => setIdeaText(e.target.value)}
              placeholder="e.g. Setting up an AI-driven organic micro-brewery using locally sourced millets in Pune..."
              className="w-full px-4 py-3 rounded-2xl bg-slate-950 border border-slate-800 text-white text-xs sm:text-sm focus:outline-none focus:border-cyan-400"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Vertical</label>
              <input
                type="text"
                value={industry}
                onChange={(e) => setIndustry(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Target Customer</label>
              <input
                type="text"
                value={targetCustomer}
                onChange={(e) => setTargetCustomer(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Starting Budget</label>
              <input
                type="text"
                value={budget}
                onChange={(e) => setBudget(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">Target Location</label>
              <input
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white text-xs focus:outline-none focus:border-cyan-400"
              />
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={isGenerating}
              className="px-6 py-3 rounded-2xl bg-gradient-to-r from-cyan-500 via-indigo-500 to-emerald-400 text-white font-bold text-xs sm:text-sm shadow-xl shadow-cyan-500/25 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-2 cursor-pointer"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Synthesizing Strategic Blueprint...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Improve My Idea with AI</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      {/* SYNTHESIZED RESULTS CANVAS */}
      <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-yellow-400" />
            <h2 className="text-base sm:text-lg font-bold text-white font-display">
              AI Strategic Blueprint & Validation Matrix
            </h2>
          </div>

          {/* Result Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto text-xs">
            <button
              onClick={() => setActiveTab('improvements')}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-colors ${
                activeTab === 'improvements'
                  ? 'bg-cyan-500 text-slate-950 font-bold'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              Strategic Angles
            </button>
            <button
              onClick={() => setActiveTab('monetization')}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-colors ${
                activeTab === 'monetization'
                  ? 'bg-cyan-500 text-slate-950 font-bold'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              Revenue Models
            </button>
            <button
              onClick={() => setActiveTab('regulatory')}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-colors ${
                activeTab === 'regulatory'
                  ? 'bg-cyan-500 text-slate-950 font-bold'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              Regulatory Feasibility
            </button>
            <button
              onClick={() => setActiveTab('growth')}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-colors ${
                activeTab === 'growth'
                  ? 'bg-cyan-500 text-slate-950 font-bold'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              Subsidies & Grants
            </button>
          </div>
        </div>

        {/* Tab Contents */}
        {activeTab === 'improvements' && (
          <div className="space-y-4 animate-in fade-in">
            <span className="text-xs font-bold uppercase tracking-wider text-cyan-400 block">
              1. Core Product & Architectural Enhancements
            </span>
            <div className="space-y-3">
              {aiResult.improvements.map((item, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-start gap-3"
                >
                  <span className="w-6 h-6 rounded-xl bg-cyan-500/20 text-cyan-400 font-mono text-xs font-bold flex items-center justify-center shrink-0">
                    {idx + 1}
                  </span>
                  <p className="text-xs sm:text-sm text-slate-200 leading-relaxed pt-0.5">{item}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'monetization' && (
          <div className="space-y-4 animate-in fade-in">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 block">
              2. Commercialization & Unit Economics
            </span>
            <div className="space-y-3">
              {aiResult.monetization.map((item, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-start gap-3"
                >
                  <span className="w-6 h-6 rounded-xl bg-emerald-500/20 text-emerald-400 font-mono text-xs font-bold flex items-center justify-center shrink-0">
                    ₹
                  </span>
                  <p className="text-xs sm:text-sm text-slate-200 leading-relaxed pt-0.5">{item}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'regulatory' && (
          <div className="space-y-4 animate-in fade-in">
            <span className="text-xs font-bold uppercase tracking-wider text-rose-400 block">
              3. Mandatory Statutory Clearances for this Concept
            </span>
            <div className="space-y-3">
              {aiResult.regulatory.map((item, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-start gap-3"
                >
                  <ShieldCheck className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                  <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">{item}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'growth' && (
          <div className="space-y-4 animate-in fade-in">
            <span className="text-xs font-bold uppercase tracking-wider text-indigo-400 block">
              4. Government Subsidies & Anchor Partnerships
            </span>
            <div className="space-y-3">
              {aiResult.growth.map((item, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex items-start gap-3"
                >
                  <Sparkles className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
                  <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">{item}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
