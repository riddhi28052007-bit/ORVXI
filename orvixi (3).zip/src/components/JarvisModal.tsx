import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  X,
  Send,
  Sparkles,
  Bot,
  RefreshCw,
  Languages,
  ArrowRight
} from 'lucide-react';
import { BusinessProfile, Language, ApprovalItem, DocumentItem, SchemeItem } from '../types';
import { TRANSLATIONS } from '../data/demoData';

interface JarvisModalProps {
  isOpen: boolean;
  onClose: () => void;
  business: BusinessProfile;
  approvals: ApprovalItem[];
  documents: DocumentItem[];
  schemes: SchemeItem[];
  language: Language;
  onLanguageChange: (lang: Language) => void;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'jarvis';
  text: string;
  timestamp: string;
}

export const JarvisModal: React.FC<JarvisModalProps> = ({
  isOpen,
  onClose,
  business,
  approvals,
  documents,
  schemes,
  language,
  onLanguageChange
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'jarvis',
      text:
        language === 'hi'
          ? 'नमस्ते! मैं जार्विस (JARVIS) हूँ—आपका ORVIXI बिज़नेस और कंप्लायंस साथी। मैं आपकी ग्रीनटेक मैन्युफैक्चरिंग कंपनी के लिए क्या कर सकता हूँ?'
          : language === 'mr'
          ? 'नमस्कार! मी जार्विस (JARVIS) आहे—तुमचा ORVIXI व्यावसायिक बुद्धिमत्ता आणि मंजुरी सहाय्यक. मी आपल्याला कशी मदत करू?'
          : 'Greetings! I am JARVIS, your executive business intelligence companion. Your compliance health is at 87%, and Factory License Form 4 is on the critical path. How may I assist you today?',
      timestamp: 'Just now'
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speechEnabled, setSpeechEnabled] = useState(true);
  const [isThinking, setIsThinking] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  const t = TRANSLATIONS[language];

  // Auto-scroll to bottom of chat
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isThinking]);

  // Speech Recognition Setup (Web Speech API)
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang =
        language === 'hi' ? 'hi-IN' : language === 'mr' ? 'mr-IN' : 'en-US';

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputText(transcript);
        handleSendQuery(transcript);
        setIsListening(false);
      };

      recognition.onerror = () => {
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }
  }, [language]);

  const toggleMic = () => {
    if (!recognitionRef.current) {
      alert('Speech recognition is not supported in this browser. Please type your query.');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      setIsListening(true);
      recognitionRef.current.start();
    }
  };

  const speakText = (text: string) => {
    if (!speechEnabled || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = language === 'hi' ? 'hi-IN' : language === 'mr' ? 'mr-IN' : 'en-US';
    utterance.rate = 1.0;
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    window.speechSynthesis.speak(utterance);
  };

  const handleSendQuery = async (queryText?: string) => {
    const q = queryText || inputText;
    if (!q.trim()) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: q,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setIsThinking(true);

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: q,
          language,
          businessProfile: business,
          currentContext: {
            approvalsCount: approvals.length,
            pendingApprovals: approvals.filter((a) => a.status !== 'completed').map((a) => a.name),
            verifiedDocs: documents.filter((d) => d.status === 'verified').length,
            activeSchemes: schemes.map((s) => s.name)
          }
        })
      });

      let replyText = '';
      if (res.ok) {
        const data = await res.json();
        replyText = data.response;
      } else {
        replyText =
          language === 'hi'
            ? 'आपके फैक्ट्री लाइसेंस (फॉर्म 4) का आवेदन अंतिम समीक्षा में है। इसके बिना MPCB कंसेंट टू ऑपरेट जारी नहीं हो सकता। कृपया अपने साइट ब्लूप्रिंट का पता अपडेट करें।'
            : language === 'mr'
            ? 'तुमचा कारखाना परवाना (फॉर्म 4) सध्या DISH अधिकाऱ्यांकडे प्रलंबित आहे. पुढील MPCB मंजुरीसाठी पत्ता दुरुस्ती करणे त्वरित आवश्यक आहे.'
            : 'Your critical bottleneck is Factory License Form 4 with DISH. Resolving the address mismatch on your site layout will immediately unblock your MPCB Consent to Operate and unlock ₹45L in PLI subsidies.';
      }

      const jarvisMsg: ChatMessage = {
        id: `jarvis-${Date.now()}`,
        sender: 'jarvis',
        text: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, jarvisMsg]);
      speakText(replyText);
    } catch (err) {
      const fallbackMsg: ChatMessage = {
        id: `jarvis-${Date.now()}`,
        sender: 'jarvis',
        text:
          'ORVIXI Intelligence offline telemetry: Your regulatory score stands at 87%. Immediate priority is verifying the Factory Site Blueprint address in the Document Validator.',
        timestamp: 'Now'
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsThinking(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-lg animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="w-full max-w-3xl h-[88vh] max-h-[750px] rounded-3xl bg-slate-900 border-2 border-cyan-500/40 shadow-2xl flex flex-col overflow-hidden relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Animated Glow Halo */}
        <div className="absolute -top-20 left-1/2 -translate-x-1/2 w-96 h-40 bg-cyan-500/15 blur-3xl pointer-events-none" />

        {/* Top Navigation Bar */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between relative z-10 bg-slate-900/90 backdrop-blur-md">
          <div className="flex items-center gap-3">
            {/* Visual Listening / Speaking Pulse Ring */}
            <div className="relative flex items-center justify-center w-10 h-10 rounded-2xl bg-gradient-to-br from-cyan-500 to-indigo-600 text-white shadow-lg shadow-cyan-500/30">
              <Bot className="w-5 h-5" />
              {(isListening || isSpeaking) && (
                <span className="absolute inset-0 rounded-2xl border-2 border-cyan-400 animate-ping opacity-75" />
              )}
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-extrabold font-display text-white tracking-wide">
                  ORVIXI JARVIS
                </h3>
                <span className="text-[10px] px-2 py-0.2 rounded-full bg-cyan-500/20 text-cyan-300 font-mono font-bold">
                  VOICE AI v4.8
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Autonomous Executive Strategic Companion
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Language Switcher */}
            <div className="flex items-center bg-slate-950 border border-slate-800 rounded-xl p-0.5 text-xs font-semibold">
              <button
                onClick={() => onLanguageChange('en')}
                className={`px-2 py-1 rounded-lg transition-colors ${
                  language === 'en' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400'
                }`}
              >
                EN
              </button>
              <button
                onClick={() => onLanguageChange('hi')}
                className={`px-2 py-1 rounded-lg transition-colors ${
                  language === 'hi' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400'
                }`}
              >
                हिं
              </button>
              <button
                onClick={() => onLanguageChange('mr')}
                className={`px-2 py-1 rounded-lg transition-colors ${
                  language === 'mr' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400'
                }`}
              >
                मरा
              </button>
            </div>

            {/* Speech Toggle */}
            <button
              onClick={() => {
                setSpeechEnabled(!speechEnabled);
                if (speechEnabled) window.speechSynthesis.cancel();
              }}
              className="p-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white"
              title={speechEnabled ? 'Mute Speech' : 'Enable Speech'}
            >
              {speechEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-rose-400" />}
            </button>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Audio Waveform Indicator */}
        {(isListening || isSpeaking) && (
          <div className="py-2 px-6 bg-cyan-950/40 border-b border-cyan-500/30 flex items-center justify-center gap-1.5">
            <span className="text-[11px] font-mono font-bold text-cyan-300 mr-2 uppercase">
              {isListening ? 'JARVIS Listening...' : 'JARVIS Speaking...'}
            </span>
            <span className="w-1 h-3 bg-cyan-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
            <span className="w-1 h-5 bg-cyan-300 rounded-full animate-bounce [animation-delay:-0.15s]" />
            <span className="w-1 h-4 bg-cyan-400 rounded-full animate-bounce" />
            <span className="w-1 h-6 bg-cyan-200 rounded-full animate-bounce [animation-delay:-0.2s]" />
            <span className="w-1 h-3 bg-cyan-400 rounded-full animate-bounce [animation-delay:-0.1s]" />
          </div>
        )}

        {/* Chat Messages Log */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[85%] sm:max-w-[75%] p-4 rounded-3xl text-xs sm:text-sm leading-relaxed space-y-1 ${
                  msg.sender === 'user'
                    ? 'bg-gradient-to-r from-cyan-600 to-indigo-600 text-white rounded-tr-sm'
                    : 'bg-slate-950/90 border border-slate-800 text-slate-200 rounded-tl-sm shadow-md'
                }`}
              >
                <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono mb-1">
                  <span>{msg.sender === 'user' ? 'You' : 'JARVIS'}</span>
                  <span>{msg.timestamp}</span>
                </div>
                <p className="whitespace-pre-line">{msg.text}</p>
                {msg.sender === 'jarvis' && (
                  <button
                    onClick={() => speakText(msg.text)}
                    className="pt-1 text-[11px] text-cyan-400 hover:underline flex items-center gap-1 cursor-pointer"
                  >
                    <Volume2 className="w-3 h-3" />
                    <span>Play Audio</span>
                  </button>
                )}
              </div>
            </div>
          ))}

          {isThinking && (
            <div className="flex justify-start">
              <div className="p-4 rounded-3xl bg-slate-950/90 border border-slate-800 text-slate-400 text-xs flex items-center gap-2 rounded-tl-sm">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-cyan-400" />
                <span>JARVIS synthesizing gazettes & compliance telemetry...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggested Queries */}
        <div className="p-3 bg-slate-950/80 border-t border-slate-800/80 overflow-x-auto flex items-center gap-2 text-[11px] text-slate-400">
          <span className="font-semibold shrink-0">Prompts:</span>
          {[
            'What is my critical path bottleneck?',
            'Check my compliance risk',
            'Explain Factory License in simple words',
            'मराठीत सांगा: मला कोणती मंजुरी हवी आहे?'
          ].map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleSendQuery(prompt)}
              className="px-3 py-1 rounded-full bg-slate-900 hover:bg-slate-800 text-slate-300 transition-colors shrink-0 border border-slate-800"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Bottom Input Field & Mic Trigger */}
        <div className="p-4 bg-slate-900 border-t border-slate-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendQuery();
            }}
            className="flex items-center gap-2"
          >
            <button
              type="button"
              onClick={toggleMic}
              className={`p-3 rounded-2xl transition-all cursor-pointer ${
                isListening
                  ? 'bg-rose-500 text-white animate-pulse shadow-lg shadow-rose-500/40'
                  : 'bg-slate-800 text-cyan-400 hover:bg-slate-700'
              }`}
              title={isListening ? 'Stop Listening' : 'Speak to JARVIS'}
            >
              {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={
                language === 'hi'
                  ? 'जार्विस से पूछें (उदा. क्या मेरा फैक्ट्री लाइसेंस तैयार है?)...'
                  : language === 'mr'
                  ? 'जार्विसला विचारा (उदा. मला कोणती मंजुरी हवी आहे?)...'
                  : 'Ask JARVIS anything about approvals, compliance, schemes...'
              }
              className="flex-1 px-4 py-3 rounded-2xl bg-slate-950 border border-slate-800 text-white text-xs sm:text-sm focus:outline-none focus:border-cyan-400"
            />

            <button
              type="submit"
              disabled={!inputText.trim()}
              className="p-3 rounded-2xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold transition-all disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <Send className="w-5 h-5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
