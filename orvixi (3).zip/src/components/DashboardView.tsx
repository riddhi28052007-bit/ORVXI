import React from 'react';
import {
  Layers,
  ShieldCheck,
  FileCheck2,
  Award,
  CheckSquare,
  Lightbulb,
  ArrowRight,
  AlertTriangle,
  Clock,
  ExternalLink,
  Bot,
  Building,
  CheckCircle2,
  Calendar,
  Sparkles,
  TrendingUp,
  FileText
} from 'lucide-react';
import {
  BusinessProfile,
  ApprovalItem,
  DocumentItem,
  SchemeItem,
  WorkspaceTask,
  ComplianceItem,
  AppView,
  Language
} from '../types';
import { TRANSLATIONS } from '../data/demoData';

interface DashboardViewProps {
  business: BusinessProfile;
  approvals: ApprovalItem[];
  documents: DocumentItem[];
  schemes: SchemeItem[];
  tasks: WorkspaceTask[];
  complianceAlerts: ComplianceItem[];
  onNavigate: (view: AppView) => void;
  onOpenJarvis: () => void;
  language: Language;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  business,
  approvals,
  documents,
  schemes,
  tasks,
  complianceAlerts,
  onNavigate,
  onOpenJarvis,
  language
}) => {
  const t = TRANSLATIONS[language];

  const totalApprovals = approvals.length;
  const completedApprovals = approvals.filter((a) => a.status === 'completed').length;
  const pendingApprovals = totalApprovals - completedApprovals;
  const verifiedDocs = documents.filter((d) => d.status === 'verified').length;
  const totalDocs = 27; // 27 total documents for demo enterprise
  const activeSchemes = schemes.length;
  const detectedWorkCount = tasks.filter((t) => !t.completed).length;

  return (
    <div className="space-y-8 pb-16 animate-in fade-in duration-200" id="orvixi-dashboard-view">
      {/* Top Welcome & Business Summary Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 p-6 rounded-3xl bg-gradient-to-r from-slate-900/90 via-slate-900/60 to-slate-950 border border-slate-800 shadow-xl">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 font-mono">
              EXECUTIVE COMMAND CENTER
            </span>
            <span className="text-xs text-slate-400 font-medium">
              Chakan Industrial Corridor, Pune • {business?.state || 'Maharashtra'}
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-display text-white tracking-tight">
            {business?.name || 'GreenTech Manufacturing Pvt. Ltd.'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            {business?.industry || 'Renewable Energy & Solar Cell Manufacturing'} • Category: <span className="text-emerald-400 font-medium">{business?.category || 'Green Industry'}</span>
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => onNavigate('business-profile')}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 hover:text-white transition-colors flex items-center gap-1.5"
          >
            <Building className="w-3.5 h-3.5 text-cyan-400" />
            <span>Profile Details</span>
          </button>
          <button
            onClick={() => onNavigate('reports')}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 hover:text-white transition-colors flex items-center gap-1.5"
          >
            <FileText className="w-3.5 h-3.5 text-indigo-400" />
            <span>Audit Reports</span>
          </button>
          <button
            onClick={onOpenJarvis}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-500 text-white text-xs font-semibold shadow-md shadow-cyan-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <Bot className="w-3.5 h-3.5" />
            <span>{t.talkToJarvis}</span>
          </button>
        </div>
      </div>

      {/* TOP 7 EXECUTIVE METRIC CARDS */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3 sm:gap-4">
        {/* 1. Total Approvals */}
        <div
          onClick={() => onNavigate('approval-mapper')}
          className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1.5">
            <span>Total Approvals</span>
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="text-2xl font-black font-display text-white group-hover:text-cyan-300 transition-colors">
            {totalApprovals}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-1">
            <span className="text-emerald-400 font-semibold">{completedApprovals} Done</span> •{' '}
            <span className="text-amber-400 font-semibold">{pendingApprovals} Pending</span>
          </div>
        </div>

        {/* 2. Pending Approvals */}
        <div
          onClick={() => onNavigate('approval-mapper')}
          className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-amber-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1.5">
            <span>Pending Action</span>
            <Clock className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-2xl font-black font-display text-amber-400">
            {pendingApprovals}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            Critical path: 2 blocked
          </div>
        </div>

        {/* 3. Compliance Score */}
        <div
          onClick={() => onNavigate('compliance')}
          className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-emerald-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1.5">
            <span>Compliance</span>
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-2xl font-black font-display text-emerald-400">
            87%
          </div>
          <div className="text-[11px] text-emerald-300/80 mt-1 font-semibold uppercase">
            Risk: LOW
          </div>
        </div>

        {/* 4. Documents Verified */}
        <div
          onClick={() => onNavigate('document-validator')}
          className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-indigo-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1.5">
            <span>Docs Verified</span>
            <FileCheck2 className="w-3.5 h-3.5 text-indigo-400" />
          </div>
          <div className="text-2xl font-black font-display text-white group-hover:text-indigo-300 transition-colors">
            24 / 27
          </div>
          <div className="text-[11px] text-amber-400 mt-1">
            3 require attention
          </div>
        </div>

        {/* 5. Scheme Matches */}
        <div
          onClick={() => onNavigate('government-schemes')}
          className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-emerald-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1.5">
            <span>Scheme Matches</span>
            <Award className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-2xl font-black font-display text-white group-hover:text-emerald-300 transition-colors">
            {activeSchemes}
          </div>
          <div className="text-[11px] text-emerald-400 mt-1">
            Top match: 94%
          </div>
        </div>

        {/* 6. AI Detected Tasks */}
        <div
          onClick={() => onNavigate('my-orvixi')}
          className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-rose-500/40 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1.5">
            <span>AI Tasks</span>
            <CheckSquare className="w-3.5 h-3.5 text-rose-400" />
          </div>
          <div className="text-2xl font-black font-display text-rose-400">
            {detectedWorkCount}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            High priority alerts
          </div>
        </div>

        {/* 7. Ideas Saved */}
        <div
          onClick={() => onNavigate('idea-lab')}
          className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-yellow-500/40 transition-all cursor-pointer group col-span-2 sm:col-span-1 lg:col-span-1"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs mb-1.5">
            <span>Ideas Saved</span>
            <Lightbulb className="w-3.5 h-3.5 text-yellow-400" />
          </div>
          <div className="text-2xl font-black font-display text-white group-hover:text-yellow-300 transition-colors">
            12
          </div>
          <div className="text-[11px] text-yellow-400/80 mt-1">
            In Idea Lab
          </div>
        </div>
      </div>

      {/* SIGNATURE "WHAT SHOULD I DO NEXT?" HERO MODULE (Section 54) */}
      <div
        id="signature-what-should-i-do-next"
        className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900/90 to-indigo-950/40 border-2 border-cyan-500/40 shadow-2xl relative overflow-hidden"
      >
        <div className="absolute -right-16 -bottom-16 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
            </span>
            <h2 className="text-lg sm:text-xl font-extrabold font-display text-white tracking-wide uppercase">
              {t.whatShouldIDoNext}
            </h2>
          </div>
          <span className="text-xs px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 font-mono border border-rose-500/30">
            URGENCY: HIGH • IMPACT: ₹45L+ UNBLOCKED
          </span>
        </div>

        {/* 6 Core Structured Dimensions: WHAT, WHY, WHEN, RISK, HOW, NEXT ACTION */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 mt-6 text-xs sm:text-sm">
          {/* WHAT */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-1.5">
            <span className="text-[11px] font-bold uppercase tracking-wider text-cyan-400">
              1. WHAT NEEDS TO BE DONE?
            </span>
            <p className="text-slate-200 font-semibold leading-snug">
              Resolve Address Mismatch on Factory Site Blueprint and submit Factory License (Form 4).
            </p>
          </div>

          {/* WHY */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-1.5">
            <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-400">
              2. WHY DOES IT MATTER?
            </span>
            <p className="text-slate-300 leading-snug">
              Unblocks 2 downstream regulatory approvals (MPCB Consent to Operate & Fire NOC) and qualifies plant for PLI grant disbursal.
            </p>
          </div>

          {/* WHEN */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-1.5">
            <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400">
              3. WHEN SHOULD IT BE COMPLETED?
            </span>
            <p className="text-slate-300 leading-snug">
              Within 4 days (before 11th September) to avoid missing the monthly DISH committee review batch.
            </p>
          </div>

          {/* RISK */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-1.5">
            <span className="text-[11px] font-bold uppercase tracking-wider text-rose-400">
              4. WHAT HAPPENS IF DELAYED?
            </span>
            <p className="text-slate-300 leading-snug">
              Commercial dispatches stay suspended, triggering ₹1,00,000 late penalty on hazardous waste storage license.
            </p>
          </div>

          {/* HOW */}
          <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-1.5">
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400">
              5. HOW CAN I COMPLETE IT?
            </span>
            <p className="text-slate-300 leading-snug">
              ORVIXI AI Document Validator has generated an auto-corrected address alignment overlay ready for digital signature.
            </p>
          </div>

          {/* NEXT ACTION */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-cyan-950/40 to-slate-950 border border-cyan-500/40 flex flex-col justify-between">
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-cyan-300">
                6. EXECUTE IMMEDIATE ACTION
              </span>
              <p className="text-slate-300 text-xs mt-1">
                One-tap auto-correction and submission.
              </p>
            </div>
            <button
              onClick={() => onNavigate('document-validator')}
              className="mt-3 w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 via-indigo-500 to-emerald-500 text-white font-bold text-xs sm:text-sm shadow-lg shadow-cyan-500/30 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Execute Fix in Validator</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* TWO-COLUMN EXECUTIVE SECTION: Approval Timeline & Compliance Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Approval Orchestration & Critical Path */}
        <div className="lg:col-span-2 space-y-6">
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white font-display">
                  Approval Orchestration Status
                </h3>
                <p className="text-xs text-slate-400">
                  Sequential pipelines, parallel tracks, and bottleneck telemetry
                </p>
              </div>
              <button
                onClick={() => onNavigate('approval-workflow')}
                className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
              >
                <span>Full Canvas</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Overall Progress Bar */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-semibold">
                <span className="text-slate-300">Overall Licensing Progress</span>
                <span className="text-cyan-400 font-mono">68% Complete (11/18)</span>
              </div>
              <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden p-0.5 border border-slate-700/60">
                <div className="bg-gradient-to-r from-cyan-500 via-indigo-500 to-emerald-400 h-full rounded-full transition-all duration-1000 w-[68%]" />
              </div>
            </div>

            {/* Pipeline Stage Indicators */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20">
                <span className="text-[10px] font-mono text-emerald-400 uppercase font-bold">Stage 1 & 2: Land & Core</span>
                <p className="text-xs font-bold text-white mt-0.5">Corporate & CTE Clearances</p>
                <div className="mt-1 flex items-center gap-1 text-[11px] text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>100% Completed</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/30">
                <span className="text-[10px] font-mono text-cyan-400 uppercase font-bold">Stage 3: Factory Licensing</span>
                <p className="text-xs font-bold text-white mt-0.5">DISH Form 4 License</p>
                <div className="mt-1 flex items-center gap-1 text-[11px] text-cyan-300">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                  <span>In Progress (Critical Path)</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20">
                <span className="text-[10px] font-mono text-amber-400 uppercase font-bold">Stage 4 & 5: Operational & BIS</span>
                <p className="text-xs font-bold text-white mt-0.5">MPCB CTO & Fire NOC</p>
                <div className="mt-1 flex items-center gap-1 text-[11px] text-amber-400">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Waiting on Stage 3</span>
                </div>
              </div>
            </div>

            {/* Pending Approvals Scannable List */}
            <div className="space-y-2 pt-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Immediate Pending Approvals (7)
              </span>
              <div className="divide-y divide-slate-800/80 rounded-2xl bg-slate-950/60 border border-slate-800">
                {approvals
                  .filter((a) => a.status !== 'completed')
                  .slice(0, 4)
                  .map((app) => (
                    <div
                      key={app.id}
                      className="p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 hover:bg-slate-900/60 transition-colors"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-white">{app.name}</span>
                          <span
                            className={`text-[9px] px-1.5 py-0.2 rounded font-mono font-bold uppercase ${
                              app.status === 'in_progress'
                                ? 'bg-cyan-500/20 text-cyan-400'
                                : 'bg-rose-500/20 text-rose-400'
                            }`}
                          >
                            {app.status.replace('_', ' ')}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          {app.authority} • Processing: ~{app.estimatedProcessingTimeDays} days
                        </p>
                      </div>
                      <button
                        onClick={() => onNavigate('approval-mapper')}
                        className="self-start sm:self-center px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium transition-colors shrink-0"
                      >
                        Details
                      </button>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right 1 Col: Compliance Risks & Proactive Alerts */}
        <div className="space-y-6">
          <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white font-display">
                  Compliance Risk Monitor
                </h3>
                <p className="text-xs text-slate-400">Upcoming statutory deadlines</p>
              </div>
              <button
                onClick={() => onNavigate('compliance')}
                className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
              >
                <span>All Alerts</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-3">
              {complianceAlerts.slice(0, 3).map((item) => (
                <div
                  key={item.id}
                  className={`p-3.5 rounded-2xl border transition-all ${
                    item.risk === 'HIGH'
                      ? 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                      : item.risk === 'MEDIUM'
                      ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                      : 'bg-slate-950 border-slate-800 text-slate-300'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-xs font-bold text-white">{item.title}</span>
                    <span
                      className={`text-[9px] px-1.5 py-0.5 rounded font-mono font-bold shrink-0 ${
                        item.risk === 'HIGH'
                          ? 'bg-rose-500/20 text-rose-400'
                          : 'bg-amber-500/20 text-amber-400'
                      }`}
                    >
                      {item.daysRemaining} days left
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                    {item.description}
                  </p>
                  <div className="mt-2.5 flex items-center justify-between pt-2 border-t border-slate-800/80">
                    <span className="text-[10px] font-mono text-slate-400">
                      Due: {item.dueDate}
                    </span>
                    <button
                      onClick={() => onNavigate('compliance')}
                      className="text-[10px] font-bold text-cyan-400 hover:underline"
                    >
                      Take Action →
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick AI Voice Teaser */}
          <div className="p-5 rounded-3xl bg-gradient-to-br from-indigo-950/60 to-slate-900 border border-indigo-500/30 space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-cyan-400">
              <Bot className="w-4 h-4" />
              <span>JARVIS Intelligent Companion</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Have questions about your Maharashtra factory filings? Ask in Hindi, Marathi, or English.
            </p>
            <button
              onClick={onOpenJarvis}
              className="w-full py-2 px-3 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/40 text-cyan-300 text-xs font-semibold transition-all flex items-center justify-center gap-2"
            >
              <span>“What is my critical path bottleneck?”</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
