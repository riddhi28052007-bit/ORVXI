import React, { useState } from 'react';
import {
  LayoutDashboard,
  Building,
  Layers,
  FileCheck2,
  GitMerge,
  ShieldAlert,
  Award,
  UserCheck,
  UserPlus,
  Lightbulb,
  Bot,
  FileBarChart2,
  Lock,
  ChevronLeft,
  ChevronRight,
  Compass,
  ArrowRight
} from 'lucide-react';
import { AppView, Language } from '../types';
import { TRANSLATIONS } from '../data/demoData';

interface SidebarProps {
  currentView: AppView;
  onNavigate: (view: AppView) => void;
  language: Language;
  onOpenJarvis: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onNavigate,
  language,
  onOpenJarvis
}) => {
  const [collapsed, setCollapsed] = useState(false);
  const t = TRANSLATIONS[language];

  const navItems = [
    { id: 'landing' as AppView, label: t.navHome, icon: Compass, badge: null },
    { id: 'dashboard' as AppView, label: t.navDashboard, icon: LayoutDashboard, badge: 'Live' },
    { id: 'business-profile' as AppView, label: t.navProfile, icon: Building, badge: null },
    { id: 'approval-mapper' as AppView, label: t.navApprovalMapper, icon: Layers, badge: '7 Pending' },
    { id: 'document-validator' as AppView, label: t.navDocValidator, icon: FileCheck2, badge: '87% OK' },
    { id: 'approval-workflow' as AppView, label: t.navWorkflow, icon: GitMerge, badge: '68%' },
    { id: 'compliance' as AppView, label: t.navCompliance, icon: ShieldAlert, badge: 'Low Risk' },
    { id: 'government-schemes' as AppView, label: t.navSchemes, icon: Award, badge: '8 Matched' },
    { id: 'my-orvixi' as AppView, label: t.navMyOrvixi, icon: UserCheck, badge: '3 Tasks' },
    { id: 'auth-portal' as AppView, label: 'Individual Portal & Auth', icon: UserPlus, badge: 'Auth' },
    { id: 'idea-lab' as AppView, label: t.navIdeaLab, icon: Lightbulb, badge: '12 Ideas' },
    { id: 'jarvis' as AppView, label: t.navJarvis, icon: Bot, badge: 'AI Core' },
    { id: 'reports' as AppView, label: t.navReports, icon: FileBarChart2, badge: null },
    { id: 'security' as AppView, label: t.navSecurity, icon: Lock, badge: 'Protected' }
  ];

  return (
    <aside
      id="orvixi-desktop-sidebar"
      className={`hidden lg:flex flex-col justify-between shrink-0 border-r border-slate-800/80 bg-slate-950/70 backdrop-blur-xl transition-all duration-300 z-30 sticky top-16 h-[calc(100vh-4rem)] select-none ${
        collapsed ? 'w-20' : 'w-64'
      }`}
    >
      {/* Top Nav List */}
      <div className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
        <div className="flex items-center justify-between px-2 mb-2">
          {!collapsed && (
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
              ORVIXI Intelligence
            </span>
          )}
          <button
            type="button"
            onClick={() => setCollapsed(!collapsed)}
            className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-850 transition-colors ml-auto"
            title={collapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
            id="toggle-sidebar-collapse"
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.id;

          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onNavigate(item.id)}
              id={`nav-item-${item.id}`}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium transition-all group cursor-pointer relative ${
                isActive
                  ? 'bg-gradient-to-r from-cyan-500/15 via-indigo-500/10 to-transparent text-cyan-400 font-semibold border-l-2 border-cyan-400'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
              }`}
              title={collapsed ? item.label : undefined}
            >
              <Icon
                className={`w-4 h-4 shrink-0 transition-transform group-hover:scale-110 ${
                  isActive ? 'text-cyan-400' : 'text-slate-400 group-hover:text-slate-200'
                }`}
              />

              {!collapsed && (
                <div className="flex items-center justify-between flex-1 truncate">
                  <span className="truncate">{item.label}</span>
                  {item.badge && (
                    <span
                      className={`ml-2 text-[10px] px-1.5 py-0.5 rounded font-mono font-normal shrink-0 ${
                        isActive
                          ? 'bg-cyan-500/20 text-cyan-300'
                          : 'bg-slate-850 text-slate-400 group-hover:bg-slate-800 text-[9px]'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </div>
              )}
            </button>
          );
        })}
      </div>

      {/* Bottom Mini Proactive Card */}
      {!collapsed ? (
        <div className="p-3 m-3 rounded-2xl bg-gradient-to-b from-slate-900 to-slate-950 border border-slate-800 shadow-lg">
          <div className="flex items-center gap-2 mb-2">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="text-[11px] font-bold text-white tracking-wide uppercase">
              What Should I Do Next?
            </span>
          </div>
          <p className="text-[11px] text-slate-400 leading-relaxed line-clamp-2">
            Address mismatch on Site Blueprint stalls Factory License. Auto-correction ready.
          </p>
          <button
            onClick={() => onNavigate('document-validator')}
            className="mt-2.5 w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 text-[11px] font-semibold transition-all group"
          >
            <span>Resolve Mismatch</span>
            <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>
      ) : (
        <div className="p-2 flex justify-center">
          <button
            onClick={onOpenJarvis}
            className="p-3 rounded-xl bg-cyan-500/20 text-cyan-400 hover:bg-cyan-500/30 transition-all"
            title="Ask JARVIS What Should I Do Next"
          >
            <Bot className="w-4 h-4 animate-bounce" />
          </button>
        </div>
      )}
    </aside>
  );
};
