import React, { useState } from 'react';
import {
  Layers,
  Search,
  CheckCircle2,
  Clock,
  AlertTriangle,
  ExternalLink,
  ChevronRight,
  Sparkles,
  HelpCircle,
  X,
  FileText,
  Calendar,
  IndianRupee,
  ShieldAlert,
  ArrowRight
} from 'lucide-react';
import { ApprovalItem, ApprovalCategory, ApprovalStatus, Language } from '../types';
import { TRANSLATIONS } from '../data/demoData';

interface ApprovalMapperViewProps {
  approvals: ApprovalItem[];
  onUpdateApprovalStatus: (id: string, newStatus: ApprovalStatus) => void;
  language: Language;
}

export const ApprovalMapperView: React.FC<ApprovalMapperViewProps> = ({
  approvals,
  onUpdateApprovalStatus,
  language
}) => {
  const [activeCategory, setActiveCategory] = useState<ApprovalCategory | 'all'>('all');
  const [activeStatus, setActiveStatus] = useState<ApprovalStatus | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedApproval, setSelectedApproval] = useState<ApprovalItem | null>(null);
  const [showSimple, setShowSimple] = useState(false);

  const t = TRANSLATIONS[language];

  const filtered = approvals.filter((a) => {
    if (activeCategory !== 'all' && a.category !== activeCategory) return false;
    if (activeStatus !== 'all' && a.status !== activeStatus) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        a.name.toLowerCase().includes(q) ||
        a.authority.toLowerCase().includes(q) ||
        a.purpose.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const getStatusBadge = (status: ApprovalStatus) => {
    switch (status) {
      case 'completed':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" />
            <span>COMPLETED</span>
          </span>
        );
      case 'in_progress':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 flex items-center gap-1">
            <Clock className="w-3 h-3 animate-spin" />
            <span>IN PROGRESS</span>
          </span>
        );
      case 'blocked':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center gap-1">
            <AlertTriangle className="w-3 h-3" />
            <span>BLOCKED</span>
          </span>
        );
      case 'pending':
      default:
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span>PENDING</span>
          </span>
        );
    }
  };

  const getCategoryBadge = (category: ApprovalCategory) => {
    switch (category) {
      case 'required':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-rose-500/15 text-rose-300">Mandatory</span>;
      case 'conditional':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/15 text-amber-300">Conditional</span>;
      case 'recommended':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-cyan-500/15 text-cyan-300">Recommended</span>;
      case 'optional':
        return <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-indigo-500/15 text-indigo-300">Optional</span>;
    }
  };

  return (
    <div className="space-y-8 pb-16 animate-in fade-in duration-200" id="orvixi-approval-mapper-view">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/80 border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 font-mono">
              CORE FEATURE // SECTION 7
            </span>
            <span className="text-xs text-slate-400 font-mono">18 Total Mapped</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-display text-white">
            Intelligent Approval Mapper
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            AI-mapped statutory clearances, conditional requirements, dependencies, and renewal lifecycles
          </p>
        </div>

        {/* Visual Pipeline Summary Chip */}
        <div className="flex items-center gap-2 px-3 py-2 rounded-2xl bg-slate-950 border border-slate-800 text-xs text-slate-300">
          <span className="text-emerald-400 font-bold">11 Completed</span>
          <span>•</span>
          <span className="text-cyan-400 font-bold">2 In Progress</span>
          <span>•</span>
          <span className="text-rose-400 font-bold">2 Blocked</span>
          <span>•</span>
          <span className="text-amber-400 font-bold">3 Pending</span>
        </div>
      </div>

      {/* Visual Workflow Stage Strip */}
      <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-center justify-between overflow-x-auto gap-3 text-xs">
        <div className="flex items-center gap-2 shrink-0">
          <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-[10px]">1</span>
          <span className="font-semibold text-white">Legal Incorporation (100%)</span>
        </div>
        <ChevronRight className="w-4 h-4 text-slate-600 shrink-0" />
        <div className="flex items-center gap-2 shrink-0">
          <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-[10px]">2</span>
          <span className="font-semibold text-white">Land & Infrastructure (100%)</span>
        </div>
        <ChevronRight className="w-4 h-4 text-slate-600 shrink-0" />
        <div className="flex items-center gap-2 shrink-0">
          <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-bold text-[10px] animate-pulse">3</span>
          <span className="font-semibold text-cyan-300">Factory Licensing (Active)</span>
        </div>
        <ChevronRight className="w-4 h-4 text-slate-600 shrink-0" />
        <div className="flex items-center gap-2 shrink-0 opacity-70">
          <span className="w-5 h-5 rounded-full bg-rose-500/20 text-rose-400 flex items-center justify-center font-bold text-[10px]">4</span>
          <span className="font-semibold text-slate-400">Pollution & Fire NOC (Blocked)</span>
        </div>
        <ChevronRight className="w-4 h-4 text-slate-600 shrink-0" />
        <div className="flex items-center gap-2 shrink-0 opacity-60">
          <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-400 flex items-center justify-center font-bold text-[10px]">5</span>
          <span className="font-semibold text-slate-400">BIS Solar Quality (Pending)</span>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Category Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <button
            onClick={() => setActiveCategory('all')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-colors shrink-0 ${
              activeCategory === 'all'
                ? 'bg-cyan-500 text-slate-950 font-bold'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            All Categories ({approvals.length})
          </button>
          <button
            onClick={() => setActiveCategory('required')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-colors shrink-0 ${
              activeCategory === 'required'
                ? 'bg-cyan-500 text-slate-950 font-bold'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Required Approvals
          </button>
          <button
            onClick={() => setActiveCategory('conditional')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-colors shrink-0 ${
              activeCategory === 'conditional'
                ? 'bg-cyan-500 text-slate-950 font-bold'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Conditional
          </button>
          <button
            onClick={() => setActiveCategory('recommended')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-colors shrink-0 ${
              activeCategory === 'recommended'
                ? 'bg-cyan-500 text-slate-950 font-bold'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Recommended
          </button>
          <button
            onClick={() => setActiveCategory('optional')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-colors shrink-0 ${
              activeCategory === 'optional'
                ? 'bg-cyan-500 text-slate-950 font-bold'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Optional
          </button>
        </div>

        {/* Search Input */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search approvals..."
            className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-cyan-400"
          />
        </div>
      </div>

      {/* Approvals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtered.map((app) => (
          <div
            key={app.id}
            className={`p-5 rounded-3xl border transition-all flex flex-col justify-between hover:shadow-xl ${
              app.status === 'in_progress'
                ? 'bg-slate-900/90 border-cyan-500/50 shadow-cyan-950/20'
                : app.status === 'blocked'
                ? 'bg-slate-900/90 border-rose-500/40 shadow-rose-950/20'
                : app.status === 'completed'
                ? 'bg-slate-900/60 border-slate-800/80 hover:border-slate-700'
                : 'bg-slate-900/80 border-slate-800 hover:border-amber-500/30'
            }`}
          >
            <div className="space-y-3">
              {/* Card Header */}
              <div className="flex items-start justify-between gap-2">
                {getCategoryBadge(app.category)}
                {getStatusBadge(app.status)}
              </div>

              {/* Title & Authority */}
              <div>
                <h3 className="text-sm font-bold text-white leading-snug">
                  {app.name}
                </h3>
                <p className="text-[11px] text-slate-400 font-medium mt-1">
                  {app.authority}
                </p>
              </div>

              {/* Purpose */}
              <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                {app.purpose}
              </p>

              {/* Metadata Pills */}
              <div className="pt-2 border-t border-slate-800/80 grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <span className="text-slate-500 block">Processing Time</span>
                  <span className="text-slate-200 font-mono font-medium">
                    ~{app.estimatedProcessingTimeDays} days
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block">Govt Fee</span>
                  <span className="text-slate-200 font-mono font-medium">
                    {app.feeEstimate}
                  </span>
                </div>
              </div>

              {/* Dependencies Alert if blocked */}
              {app.dependencies.length > 0 && app.status === 'blocked' && (
                <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-[11px] text-rose-300 flex items-start gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                  <span>
                    Blocked: Requires <strong>Factory License (DISH)</strong> completion first.
                  </span>
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="mt-5 pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
              <button
                onClick={() => {
                  setSelectedApproval(app);
                  setShowSimple(false);
                }}
                className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 transition-colors flex items-center gap-1 cursor-pointer"
              >
                <span>Inspect Dossier</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <div className="flex items-center gap-1.5">
                {app.status !== 'completed' && (
                  <button
                    onClick={() =>
                      onUpdateApprovalStatus(
                        app.id,
                        app.status === 'in_progress' ? 'completed' : 'in_progress'
                      )
                    }
                    className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-semibold transition-colors"
                  >
                    {app.status === 'in_progress' ? 'Mark Completed' : 'Start'}
                  </button>
                )}
                {app.portalUrl && (
                  <a
                    href={app.portalUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="p-1 rounded-lg text-slate-400 hover:text-white transition-colors"
                    title="Open official portal"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* INSPECTION MODAL */}
      {selectedApproval && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-150"
          onClick={() => setSelectedApproval(null)}
        >
          <div
            className="w-full max-w-2xl rounded-3xl bg-slate-900 border border-slate-700 shadow-2xl p-6 sm:p-8 space-y-6 max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-800">
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  {getCategoryBadge(selectedApproval.category)}
                  {getStatusBadge(selectedApproval.status)}
                </div>
                <h2 className="text-xl font-bold font-display text-white">
                  {selectedApproval.name}
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  {selectedApproval.authority} • {selectedApproval.department}
                </p>
              </div>
              <button
                onClick={() => setSelectedApproval(null)}
                className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* "Explain Simply" Interactive Toggle */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-indigo-950/60 to-slate-950 border border-indigo-500/30 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-xs font-semibold text-indigo-300">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span>Explain Simply Feature</span>
              </div>
              <button
                onClick={() => setShowSimple(!showSimple)}
                className="px-3 py-1 rounded-xl bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 text-xs font-semibold transition-colors border border-indigo-500/30"
              >
                {showSimple ? 'Show Legal Definition' : t.explainSimply}
              </button>
            </div>

            {showSimple ? (
              <div className="p-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-xs sm:text-sm text-cyan-200 leading-relaxed">
                <p className="font-semibold text-white mb-1">
                  Plain Language Explanation:
                </p>
                <p>
                  {language === 'hi'
                    ? selectedApproval.simpleExplanationHi || selectedApproval.simpleExplanation
                    : language === 'mr'
                    ? selectedApproval.simpleExplanationMr || selectedApproval.simpleExplanation
                    : selectedApproval.simpleExplanation}
                </p>
              </div>
            ) : (
              <div className="space-y-3 text-xs sm:text-sm">
                <div>
                  <span className="text-slate-400 text-xs font-bold uppercase tracking-wider block mb-1">
                    Statutory Purpose
                  </span>
                  <p className="text-slate-200 leading-relaxed">
                    {selectedApproval.purpose}
                  </p>
                </div>
                <div>
                  <span className="text-slate-400 text-xs font-bold uppercase tracking-wider block mb-1">
                    Eligibility Criteria
                  </span>
                  <p className="text-slate-300 leading-relaxed">
                    {selectedApproval.eligibility}
                  </p>
                </div>
              </div>
            )}

            {/* Required Documents List */}
            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Required Verification Documents
              </span>
              <div className="space-y-1.5">
                {selectedApproval.requiredDocuments.map((doc, idx) => (
                  <div
                    key={idx}
                    className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 flex items-center gap-2"
                  >
                    <FileText className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                    <span>{doc}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Lifecycle & Details */}
            <div className="grid grid-cols-2 gap-4 p-4 rounded-2xl bg-slate-950 border border-slate-800 text-xs">
              <div>
                <span className="text-slate-500 block">Renewal Mandate</span>
                <span className="text-slate-300 font-medium">
                  {selectedApproval.renewalRequirement}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">Estimated Processing</span>
                <span className="text-slate-300 font-mono font-medium">
                  ~{selectedApproval.estimatedProcessingTimeDays} Business Days
                </span>
              </div>
            </div>

            {/* Modal Footer Controls */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-800">
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400">Status Control:</span>
                <select
                  value={selectedApproval.status}
                  onChange={(e) => {
                    const newSt = e.target.value as ApprovalStatus;
                    onUpdateApprovalStatus(selectedApproval.id, newSt);
                    setSelectedApproval({ ...selectedApproval, status: newSt });
                  }}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none"
                >
                  <option value="pending">Pending</option>
                  <option value="in_progress">In Progress</option>
                  <option value="completed">Completed</option>
                  <option value="blocked">Blocked</option>
                </select>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                {selectedApproval.portalUrl && (
                  <a
                    href={selectedApproval.portalUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white flex items-center gap-1.5 transition-colors"
                  >
                    <span>Launch Portal</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
                <button
                  onClick={() => setSelectedApproval(null)}
                  className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-colors"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
