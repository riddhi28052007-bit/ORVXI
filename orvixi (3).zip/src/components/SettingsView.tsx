import React, { useState } from 'react';
import {
  Settings as SettingsIcon,
  Languages,
  Bell,
  Sliders,
  Shield,
  RotateCcw,
  Check,
  Save,
  Globe,
  MapPin,
  Building
} from 'lucide-react';
import { Language, BusinessProfile } from '../types';
import { TRANSLATIONS, DEFAULT_BUSINESS_PROFILE } from '../data/demoData';

interface SettingsViewProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  business: BusinessProfile;
  onResetDemoData: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  language,
  onLanguageChange,
  business,
  onResetDemoData
}) => {
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [smsAlerts, setSmsAlerts] = useState(true);
  const [dailyDigest, setDailyDigest] = useState(false);
  const [complianceNoticeThresholdDays, setComplianceNoticeThresholdDays] = useState(15);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const t = TRANSLATIONS[language];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="space-y-8 pb-16 animate-in fade-in duration-200" id="orvixi-settings-view">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/80 border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 font-mono">
              SYSTEM CONFIGURATION
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-display text-white">
            Workspace Settings & Preferences
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Configure regional language engines, statutory escalation frequencies, and industrial parameters
          </p>
        </div>

        {savedSuccess && (
          <div className="px-4 py-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold flex items-center gap-2">
            <Check className="w-4 h-4" />
            <span>Preferences Saved</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        {/* Language & Regional Engine */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-white">
            <Globe className="w-4 h-4 text-cyan-400" />
            <span>Language & Vernacular Intelligence</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {[
              { code: 'en', label: 'English (Default)', note: 'Statutory Gazettes & Central Acts' },
              { code: 'hi', label: 'हिंदी (Hindi)', note: 'सरल व्याख्या और जार्विस सहायता' },
              { code: 'mr', label: 'मराठी (Marathi)', note: 'महाराष्ट्र शासन आणि MIDC अधिसूचना' }
            ].map((langObj) => (
              <div
                key={langObj.code}
                onClick={() => onLanguageChange(langObj.code as Language)}
                className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                  language === langObj.code
                    ? 'bg-slate-950 border-cyan-500 text-white shadow-md'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                <span className="text-xs font-bold block">{langObj.label}</span>
                <span className="text-[11px] text-slate-500 mt-1 block">{langObj.note}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Proactive Compliance Alert Frequencies */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-white">
            <Bell className="w-4 h-4 text-amber-400" />
            <span>Statutory Notification Channels & Escalations</span>
          </div>

          <div className="space-y-3 text-xs">
            <label className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-950 border border-slate-800 cursor-pointer">
              <div>
                <span className="font-semibold text-white block">Email Escalations</span>
                <span className="text-slate-400 text-[11px]">
                  Send critical penalty warnings (DISH, MPCB, GST) to directors
                </span>
              </div>
              <input
                type="checkbox"
                checked={emailAlerts}
                onChange={(e) => setEmailAlerts(e.target.checked)}
                className="w-4 h-4 rounded text-cyan-500 focus:ring-cyan-400"
              />
            </label>

            <label className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-950 border border-slate-800 cursor-pointer">
              <div>
                <span className="font-semibold text-white block">SMS & WhatsApp Critical Alerts</span>
                <span className="text-slate-400 text-[11px]">
                  Instant notification 72 hours before license expiry or inspection date
                </span>
              </div>
              <input
                type="checkbox"
                checked={smsAlerts}
                onChange={(e) => setSmsAlerts(e.target.checked)}
                className="w-4 h-4 rounded text-cyan-500 focus:ring-cyan-400"
              />
            </label>

            <label className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-950 border border-slate-800 cursor-pointer">
              <div>
                <span className="font-semibold text-white block">Daily Morning Intelligence Digest</span>
                <span className="text-slate-400 text-[11px]">
                  Summary of newly released Maharashtra state industrial subsidies
                </span>
              </div>
              <input
                type="checkbox"
                checked={dailyDigest}
                onChange={(e) => setDailyDigest(e.target.checked)}
                className="w-4 h-4 rounded text-cyan-500 focus:ring-cyan-400"
              />
            </label>
          </div>
        </div>

        {/* Industrial Site Geofencing */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-white">
            <MapPin className="w-4 h-4 text-emerald-400" />
            <span>Industrial Zone & MIDC Cluster Mapping</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block text-slate-400 font-semibold mb-1">MIDC Zone Allotment</label>
              <input
                type="text"
                readOnly
                value="Chakan MIDC Phase IV, Pune District"
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-300"
              />
            </div>
            <div>
              <label className="block text-slate-400 font-semibold mb-1">State Single Window Portal ID</label>
              <input
                type="text"
                readOnly
                value="MAITRI-CORP-2023-99410"
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-cyan-400 font-mono"
              />
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4">
          <button
            type="button"
            onClick={onResetDemoData}
            className="px-4 py-2.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/30 text-rose-300 text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset Demo Data to GreenTech Manufacturing</span>
          </button>

          <button
            type="submit"
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-500 hover:opacity-90 text-white font-bold text-xs shadow-lg shadow-cyan-500/25 flex items-center gap-2 transition-all cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>Save Settings</span>
          </button>
        </div>
      </form>
    </div>
  );
};
