import React, { useState } from 'react';
import {
  GitMerge,
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ArrowRight,
  ArrowDown,
  Layers,
  Sparkles,
  Zap,
  Info
} from 'lucide-react';
import { ApprovalItem, Language } from '../types';
import { TRANSLATIONS } from '../data/demoData';

interface ApprovalWorkflowViewProps {
  approvals: ApprovalItem[];
  language: Language;
}

export const ApprovalWorkflowView: React.FC<ApprovalWorkflowViewProps> = ({
  approvals,
  language
}) => {
  const [workflowState, setWorkflowState] = useState<'running' | 'paused'>('running');
  const [activeStageFilter, setActiveStageFilter] = useState<number | 'all'>('all');
  const [selectedNode, setSelectedNode] = useState<ApprovalItem | null>(null);

  const t = TRANSLATIONS[language];

  // Group approvals into 5 logical stages
  const stages = [
    { stage: 1, title: 'Legal & Tax Foundation', description: 'Corporate entity, PAN, GST, MSME, EPFO' },
    { stage: 2, title: 'Land & Infrastructure', description: 'MIDC plot allotment, Building plan, Power, MPCB CTE' },
    { stage: 3, title: 'Factory Licensing (Critical)', description: 'DISH Form 4 Factory License for 142 workers' },
    { stage: 4, title: 'Safety & Environmental Operating', description: 'MPCB Consent to Operate & Fire NOC' },
    { stage: 5, title: 'Commercial Quality Standards', description: 'BIS CRS certification & ALMM solar empanelment' }
  ];

  return (
    <div className="space-y-8 pb-16 animate-in fade-in duration-200" id="orvixi-approval-workflow-view">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/80 border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 font-mono">
              CORE FEATURE // SECTION 9
            </span>
            <span className="text-xs text-slate-400 font-mono">Neural Orchestration Engine</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-display text-white">
            Approval Orchestration Canvas
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Visual dependency mapping: Sequential, Parallel, Dependent, and Blocked regulatory pathways
          </p>
        </div>

        {/* Workflow Controls */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setWorkflowState(workflowState === 'running' ? 'paused' : 'running')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              workflowState === 'running'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
            }`}
          >
            {workflowState === 'running' ? (
              <>
                <Pause className="w-3.5 h-3.5" />
                <span>Pause Orchestrator</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5" />
                <span>Resume Pipeline</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* OVERALL PROGRESS & BOTTLENECK RADAR */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 font-bold uppercase">Pipeline Progress</span>
            <span className="text-cyan-400 font-mono font-bold text-sm">68%</span>
          </div>
          <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden p-0.5">
            <div className="bg-gradient-to-r from-cyan-500 via-indigo-500 to-emerald-400 h-full rounded-full w-[68%]" />
          </div>
          <div className="flex justify-between text-[11px] text-slate-400 font-mono">
            <span>11 Completed</span>
            <span>2 In Progress</span>
            <span>2 Blocked</span>
          </div>
        </div>

        <div className="md:col-span-2 p-6 rounded-3xl bg-slate-900/90 border border-rose-500/30 space-y-2 relative overflow-hidden">
          <div className="flex items-center gap-2 text-xs font-bold text-rose-400 uppercase tracking-wider">
            <AlertTriangle className="w-4 h-4" />
            <span>Active Bottleneck Detected</span>
          </div>
          <p className="text-xs sm:text-sm font-bold text-white">
            Factory License Form 4 (Directorate of Industrial Safety & Health)
          </p>
          <p className="text-xs text-slate-300 leading-relaxed">
            This node represents the <strong>critical path bottleneck</strong>. Two high-priority downstream nodes (<strong>MPCB Consent to Operate</strong> and <strong>Fire Safety NOC</strong>) are strictly blocked waiting on this approval grant.
          </p>
        </div>
      </div>

      {/* INTERACTIVE WORKFLOW NODES CANVAS */}
      <div className="space-y-6">
        {stages.map((stageObj) => {
          const stageApprovals = approvals.filter((a) => a.stage === stageObj.stage);
          const isCompletedStage = stageApprovals.every((a) => a.status === 'completed');
          const isCriticalActiveStage = stageApprovals.some((a) => a.status === 'in_progress');
          const isBlockedStage = stageApprovals.some((a) => a.status === 'blocked');

          return (
            <div
              key={stageObj.stage}
              className={`p-6 rounded-3xl border transition-all ${
                isCompletedStage
                  ? 'bg-slate-900/60 border-slate-800'
                  : isCriticalActiveStage
                  ? 'bg-slate-900/95 border-cyan-500/60 shadow-xl shadow-cyan-950/30'
                  : isBlockedStage
                  ? 'bg-slate-900/80 border-rose-500/30'
                  : 'bg-slate-900/70 border-slate-800'
              }`}
            >
              {/* Stage Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-800/80 mb-4">
                <div className="flex items-center gap-3">
                  <span
                    className={`w-7 h-7 rounded-xl flex items-center justify-center font-bold text-xs font-mono ${
                      isCompletedStage
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                        : isCriticalActiveStage
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 animate-pulse'
                        : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    0{stageObj.stage}
                  </span>
                  <div>
                    <h3 className="text-sm sm:text-base font-bold text-white font-display">
                      {stageObj.title}
                    </h3>
                    <p className="text-[11px] text-slate-400">{stageObj.description}</p>
                  </div>
                </div>

                <span
                  className={`text-[10px] px-2.5 py-0.5 rounded-full font-mono font-bold self-start sm:self-center ${
                    isCompletedStage
                      ? 'bg-emerald-500/20 text-emerald-400'
                      : isCriticalActiveStage
                      ? 'bg-cyan-500/20 text-cyan-300'
                      : isBlockedStage
                      ? 'bg-rose-500/20 text-rose-400'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  {isCompletedStage
                    ? 'STAGE COMPLETED'
                    : isCriticalActiveStage
                    ? 'ACTIVE PIPELINE'
                    : isBlockedStage
                    ? 'DEPENDENCY BLOCKED'
                    : 'UPCOMING'}
                </span>
              </div>

              {/* Approval Nodes in this Stage */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {stageApprovals.map((node) => (
                  <div
                    key={node.id}
                    onClick={() => setSelectedNode(node)}
                    className={`p-4 rounded-2xl border text-xs space-y-2 cursor-pointer transition-all hover:scale-[1.01] ${
                      node.status === 'completed'
                        ? 'bg-slate-950/80 border-slate-800 hover:border-slate-700'
                        : node.status === 'in_progress'
                        ? 'bg-slate-950 border-cyan-500/50 shadow-md shadow-cyan-950/30'
                        : node.status === 'blocked'
                        ? 'bg-slate-950 border-rose-500/40'
                        : 'bg-slate-950 border-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-slate-500 font-mono">
                        Stage {node.stage} Node
                      </span>
                      <span
                        className={`text-[9px] px-1.5 py-0.2 rounded font-mono font-bold uppercase ${
                          node.status === 'completed'
                            ? 'bg-emerald-500/20 text-emerald-400'
                            : node.status === 'in_progress'
                            ? 'bg-cyan-500/20 text-cyan-400'
                            : 'bg-rose-500/20 text-rose-400'
                        }`}
                      >
                        {node.status}
                      </span>
                    </div>

                    <h4 className="text-xs font-bold text-white line-clamp-1">{node.name}</h4>
                    <p className="text-[11px] text-slate-400 line-clamp-1">{node.authority}</p>

                    {node.dependencies.length > 0 && (
                      <div className="pt-2 border-t border-slate-800 text-[10px] text-slate-500 flex items-center gap-1 font-mono">
                        <GitMerge className="w-3 h-3 text-cyan-400 shrink-0" />
                        <span>Depends on: {node.dependencies.join(', ')}</span>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* NODE DETAILS MODAL */}
      {selectedNode && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in"
          onClick={() => setSelectedNode(null)}
        >
          <div
            className="w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-700 p-6 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between pb-3 border-b border-slate-800">
              <div>
                <span className="text-xs font-mono text-cyan-400">Node ID: {selectedNode.id}</span>
                <h3 className="text-base font-bold text-white mt-0.5">{selectedNode.name}</h3>
                <p className="text-xs text-slate-400">{selectedNode.authority}</p>
              </div>
              <button
                onClick={() => setSelectedNode(null)}
                className="text-slate-400 hover:text-white text-xs"
              >
                Close
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <span className="text-slate-400 block font-semibold mb-0.5">Purpose:</span>
                <p className="text-slate-200">{selectedNode.purpose}</p>
              </div>
              <div>
                <span className="text-slate-400 block font-semibold mb-0.5">Status:</span>
                <span className="font-mono text-cyan-400 font-bold uppercase">
                  {selectedNode.status}
                </span>
              </div>
              {selectedNode.dependencies.length > 0 && (
                <div>
                  <span className="text-slate-400 block font-semibold mb-0.5">Prerequisites:</span>
                  <p className="text-slate-300 font-mono">
                    Must complete approvals: {selectedNode.dependencies.join(', ')}
                  </p>
                </div>
              )}
            </div>

            <button
              onClick={() => setSelectedNode(null)}
              className="w-full py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs"
            >
              Done
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
