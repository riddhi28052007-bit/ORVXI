import React, { useState } from 'react';
import {
  Award,
  Search,
  Sparkles,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  FileText,
  Calendar,
  IndianRupee,
  Check,
  Send,
  HelpCircle,
  ArrowRight,
  Filter
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { SchemeItem, Language } from '../types';
import { TRANSLATIONS } from '../data/demoData';

interface GovernmentSchemesViewProps {
  schemes: SchemeItem[];
  language: Language;
}

export const GovernmentSchemesView: React.FC<GovernmentSchemesViewProps> = ({
  schemes,
  language
}) => {
  const [selectedScheme, setSelectedScheme] = useState<SchemeItem | null>(null);
  const [filterType, setFilterType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [appliedSchemes, setAppliedSchemes] = useState<string[]>([]);
  const [userQuery, setUserQuery] = useState('');
  const [aiCheckerResponse, setAiCheckerResponse] = useState<string | null>(null);
  const [isEvaluating, setIsEvaluating] = useState(false);

  const t = TRANSLATIONS[language];

  const filtered = schemes.filter((s) => {
    if (filterType !== 'all' && s.benefitType.toLowerCase() !== filterType.toLowerCase()) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        s.name.toLowerCase().includes(q) ||
        s.department.toLowerCase().includes(q) ||
        s.description.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleApply = (id: string) => {
    if (!appliedSchemes.includes(id)) {
      setAppliedSchemes([...appliedSchemes, id]);
      confetti({ particleCount: 70, spread: 65, origin: { y: 0.65 } });
    }
  };

  const handleAskChecker = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userQuery.trim()) return;
    setIsEvaluating(true);

    setTimeout(() => {
      setIsEvaluating(false);
      const q = userQuery.toLowerCase();
      if (q.includes('pli') || q.includes('solar')) {
        setAiCheckerResponse(
          `**Eligibility Analysis for PLI Scheme Solar PV:**\n\n- **Eligibility Score:** 94%\n- **Matched Criteria:** Domestic manufacturing plant in Maharashtra, Capital expenditure > ₹10 Cr, module efficiency > 20.5%.\n- **Pending Requirement:** BIS CRS final grant letter (Form 4 pending with lab).\n- **Recommended Next Action:** Expedite NISE lab report to submit application before 25th September.`
        );
      } else if (q.includes('document') || q.includes('कागजात')) {
        setAiCheckerResponse(
          `**Mandatory Documents for Highest Matching Schemes:**\n\n1. Udyam MSME Certificate (Verified)\n2. Chartered Accountant Net Worth & Fixed Asset Certificate\n3. NABL Type-Test Report from CPRI (Attached: 21.84% verified output)\n4. Pollution Board CTE & Factory Occupation Certificate.`
        );
      } else {
        setAiCheckerResponse(
          `**GreenTech Manufacturing Eligibility Overview:**\n\nYour business is eligible for **8 State and Central Incentive Schemes** totaling **₹1.45 Crores** in cash incentives, tax refunds, and subsidized credit.\n\nTop 2 priority submissions: **Production Linked Incentive (PLI Solar)** and **Maharashtra PSI 2019 Capital Subsidy**.`
        );
      }
    }, 800);
  };

  return (
    <div className="space-y-8 pb-16 animate-in fade-in duration-200" id="orvixi-schemes-view">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/80 border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 font-mono">
              CORE FEATURE // SECTION 12 & 13
            </span>
            <span className="text-xs text-slate-400 font-mono">8 Matches Available</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-display text-white">
            Government Support & Incentive Matcher
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            AI-matched capital subsidies, low-interest working capital, tax exemptions, and government tenders
          </p>
        </div>

        <div className="flex items-center gap-3 px-4 py-2.5 rounded-2xl bg-slate-950 border border-slate-800">
          <div className="text-right">
            <span className="text-[11px] text-slate-400 uppercase font-semibold">Total Potential Benefit</span>
            <span className="text-base font-bold font-mono text-emerald-400">₹1.45 Crores</span>
          </div>
        </div>
      </div>

      {/* AI ELIGIBILITY CHECKER INTERACTIVE SEARCH (Section 13) */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950/40 to-slate-900 border border-cyan-500/30 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 uppercase tracking-wider">
            <Sparkles className="w-4 h-4" />
            <span>AI Natural Language Eligibility Checker</span>
          </div>
          <span className="text-xs text-slate-400">Ask any eligibility question</span>
        </div>

        <form onSubmit={handleAskChecker} className="flex gap-2">
          <input
            type="text"
            value={userQuery}
            onChange={(e) => setUserQuery(e.target.value)}
            placeholder="e.g. 'Which subsidies am I eligible for in Maharashtra?', 'What documents do I need for PLI?'"
            className="flex-1 px-4 py-3 rounded-2xl bg-slate-950/80 border border-slate-700 text-white text-xs sm:text-sm focus:outline-none focus:border-cyan-400"
          />
          <button
            type="submit"
            disabled={isEvaluating}
            className="px-5 py-3 rounded-2xl bg-gradient-to-r from-cyan-500 to-indigo-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-cyan-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-1.5 cursor-pointer shrink-0"
          >
            {isEvaluating ? (
              <span>Evaluating...</span>
            ) : (
              <>
                <span>Check Eligibility</span>
                <Send className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {aiCheckerResponse && (
          <div className="p-5 rounded-2xl bg-slate-950/90 border border-cyan-500/40 text-xs sm:text-sm text-slate-200 leading-relaxed whitespace-pre-line animate-in fade-in">
            {aiCheckerResponse}
          </div>
        )}

        {/* Quick Question Chips */}
        <div className="flex items-center gap-2 overflow-x-auto text-[11px] text-slate-400 pt-1">
          <span className="font-semibold shrink-0">Sample prompts:</span>
          {[
            'Am I eligible for PLI Solar?',
            'What documents do I need for capital subsidies?',
            'Show tax exemptions for renewable manufacturing'
          ].map((q, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => {
                setUserQuery(q);
              }}
              className="px-3 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors shrink-0"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* FILTER & SEARCH TABS */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          {['all', 'subsidy', 'grant', 'tax incentive', 'low-interest loan'].map((type) => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-3 py-1.5 rounded-xl font-semibold capitalize transition-colors shrink-0 ${
                filterType === type
                  ? 'bg-cyan-500 text-slate-950 font-bold'
                  : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {type}
            </button>
          ))}
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search schemes..."
            className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-cyan-400"
          />
        </div>
      </div>

      {/* SCHEMES GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filtered.map((sch) => {
          const isApplied = appliedSchemes.includes(sch.id);
          return (
            <div
              key={sch.id}
              className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 hover:border-emerald-500/40 transition-all flex flex-col justify-between space-y-4 hover:shadow-xl"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-indigo-500/15 text-indigo-300 border border-indigo-500/30">
                    {sch.benefitType}
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                    {sch.eligibilityScore}% MATCH
                  </span>
                </div>

                <div>
                  <h3 className="text-base font-bold text-white leading-snug">
                    {sch.name}
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    {sch.department} • {sch.ministry}
                  </p>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  {sch.description}
                </p>

                <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs font-mono">
                  <div>
                    <span className="text-slate-500 block text-[10px]">Potential Grant Benefit</span>
                    <span className="text-emerald-400 font-bold">{sch.benefitAmount}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-slate-500 block text-[10px]">Deadline</span>
                    <span className="text-slate-300">{sch.deadline}</span>
                  </div>
                </div>

                {/* Criteria matched */}
                <div className="space-y-1 text-xs">
                  <span className="text-[11px] font-bold text-slate-400 uppercase">
                    AI Verified Eligibility Highlights:
                  </span>
                  {sch.matchedCriteria.slice(0, 2).map((crit, i) => (
                    <div key={i} className="flex items-center gap-1.5 text-emerald-400 text-[11px]">
                      <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                      <span>{crit}</span>
                    </div>
                  ))}
                  {sch.missingCriteria.length > 0 && (
                    <div className="flex items-center gap-1.5 text-amber-400 text-[11px]">
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                      <span>Pending: {sch.missingCriteria[0]}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                <button
                  onClick={() => setSelectedScheme(sch)}
                  className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
                >
                  <span>Required Documents</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleApply(sch.id)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                      isApplied
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950'
                    }`}
                  >
                    {isApplied ? 'Application In Draft' : 'Add to Applications'}
                  </button>
                  {sch.portalLink && (
                    <a
                      href={sch.portalLink}
                      target="_blank"
                      rel="noreferrer"
                      className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                      title="Open official portal"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* SCHEME DETAIL MODAL */}
      {selectedScheme && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in"
          onClick={() => setSelectedScheme(null)}
        >
          <div
            className="w-full max-w-xl rounded-3xl bg-slate-900 border border-slate-700 p-6 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start justify-between pb-3 border-b border-slate-800">
              <div>
                <span className="text-xs font-mono text-emerald-400 font-bold">
                  {selectedScheme.eligibilityScore}% Match • {selectedScheme.benefitType}
                </span>
                <h3 className="text-base font-bold text-white mt-1">{selectedScheme.name}</h3>
                <p className="text-xs text-slate-400">{selectedScheme.department}</p>
              </div>
              <button
                onClick={() => setSelectedScheme(null)}
                className="text-slate-400 hover:text-white text-xs"
              >
                Close
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <span className="text-slate-400 block font-semibold mb-1">
                  Required Application Documents:
                </span>
                <div className="space-y-1.5">
                  {selectedScheme.requiredDocuments.map((doc, i) => (
                    <div
                      key={i}
                      className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-2 text-slate-200"
                    >
                      <FileText className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span>{doc}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-300">
                <span>
                  Estimated benefit: <strong>{selectedScheme.benefitAmount}</strong>. ORVIXI AI can assemble your application dossier automatically.
                </span>
              </div>
            </div>

            <button
              onClick={() => setSelectedScheme(null)}
              className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs"
            >
              Got It
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
