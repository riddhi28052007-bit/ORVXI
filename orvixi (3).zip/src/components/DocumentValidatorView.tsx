import React, { useState, useRef } from 'react';
import {
  FileCheck2,
  Upload,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  FileText,
  Sparkles,
  RefreshCw,
  Wrench,
  Eye,
  Check,
  Calendar,
  Layers,
  ArrowRight,
  ShieldCheck
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { DocumentItem, Language } from '../types';
import { TRANSLATIONS } from '../data/demoData';

interface DocumentValidatorViewProps {
  documents: DocumentItem[];
  onUpdateDocument: (doc: DocumentItem) => void;
  language: Language;
}

export const DocumentValidatorView: React.FC<DocumentValidatorViewProps> = ({
  documents,
  onUpdateDocument,
  language
}) => {
  const [selectedDoc, setSelectedDoc] = useState<DocumentItem>(documents[2] || documents[0]); // default to the one with issues (Factory layout)
  const [isProcessing, setIsProcessing] = useState(false);
  const [fixApplied, setFixApplied] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const t = TRANSLATIONS[language];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement> | React.DragEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setFixApplied(false);

    setTimeout(() => {
      setIsProcessing(false);
      // Create new scanned document
      const newDoc: DocumentItem = {
        id: `doc-${Date.now()}`,
        name: 'Uploaded_Statutory_Dossier_2026.pdf',
        category: 'Statutory Filing',
        fileType: 'PDF',
        fileSize: '3.4 MB',
        uploadDate: new Date().toISOString().split('T')[0],
        expiryDate: '2028-09-01',
        status: 'verified',
        healthScore: 94,
        matchedFields: [
          { field: 'Entity Name', value: 'GreenTech Manufacturing Pvt. Ltd.', status: 'match' },
          { field: 'Registration Number', value: 'U29300MH2023PTC401290', status: 'match' },
          { field: 'Authorized Signatory', value: 'Director Verified', status: 'match' },
          { field: 'State Authority Stamp', value: 'Govt of Maharashtra Seal Detected', status: 'match' }
        ],
        issues: []
      };

      onUpdateDocument(newDoc);
      setSelectedDoc(newDoc);
      confetti({ particleCount: 60, spread: 60, origin: { y: 0.7 } });
    }, 1400);
  };

  const handleAutoFix = () => {
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setFixApplied(true);
      const updated: DocumentItem = {
        ...selectedDoc,
        healthScore: 98,
        status: 'verified',
        issues: [],
        matchedFields: selectedDoc.matchedFields.map((f) => ({
          ...f,
          status: 'match',
          value: f.field.includes('Address') ? 'Plot C-14, Chakan MIDC Phase IV (Aligned)' : f.value
        }))
      };
      setSelectedDoc(updated);
      onUpdateDocument(updated);
      confetti({ particleCount: 75, spread: 70, origin: { y: 0.6 } });
    }, 1000);
  };

  return (
    <div className="space-y-8 pb-16 animate-in fade-in duration-200" id="orvixi-document-validator-view">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/80 border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 font-mono">
              CORE FEATURE // SECTION 8
            </span>
            <span className="text-xs text-slate-400 font-mono">OCR Engine v4.2</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-display text-white">
            AI Document Validator & OCR Suite
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Extract → Analyze → Verify → Detect Inconsistencies → Auto-Fix Alignment
          </p>
        </div>

        {/* Global Document Health Score */}
        <div className="flex items-center gap-3 px-4 py-2.5 rounded-2xl bg-slate-950 border border-slate-800">
          <div className="text-right">
            <span className="text-[11px] text-slate-400 block font-medium">Enterprise Health Score</span>
            <span className="text-base font-bold font-mono text-emerald-400">87% Healthy</span>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-mono font-bold text-sm">
            87%
          </div>
        </div>
      </div>

      {/* DRAG & DROP UPLOAD ZONE (Section 8) */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          setDragOver(false);
          handleFileUpload(e);
        }}
        onClick={() => fileInputRef.current?.click()}
        className={`p-8 sm:p-10 rounded-3xl border-2 border-dashed transition-all cursor-pointer text-center relative overflow-hidden group ${
          dragOver
            ? 'border-cyan-400 bg-cyan-500/10'
            : 'border-slate-800 hover:border-cyan-500/50 bg-slate-900/60 hover:bg-slate-900/90'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".pdf,.png,.jpg,.jpeg,.docx"
          onChange={handleFileUpload}
          className="hidden"
        />

        <div className="max-w-md mx-auto space-y-3">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition-transform">
            {isProcessing ? (
              <RefreshCw className="w-6 h-6 animate-spin" />
            ) : (
              <Upload className="w-6 h-6" />
            )}
          </div>
          <div>
            <h3 className="text-sm sm:text-base font-bold text-white">
              {isProcessing
                ? 'Performing Neural OCR & Field Cross-Matching...'
                : 'Upload Regulatory Document for AI OCR Verification'}
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Supports PDF, PNG, JPG, DOCX • Drag and drop or click to browse
            </p>
          </div>
          <div className="flex items-center justify-center gap-2 pt-2 text-[11px] text-slate-500 font-mono">
            <span>✓ Field Matching</span>
            <span>•</span>
            <span>✓ Expiry Watch</span>
            <span>•</span>
            <span>✓ DIC & MCA Cross-Ref</span>
          </div>
        </div>
      </div>

      {/* TWO-PANEL INTERACTIVE VALIDATION CANVAS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: List of All Uploaded Business Documents */}
        <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-white font-display">Document Dossier</h3>
              <p className="text-[11px] text-slate-400">27 files in secure repository</p>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
              24 Verified
            </span>
          </div>

          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
            {documents.map((doc) => {
              const isSelected = selectedDoc.id === doc.id;
              return (
                <div
                  key={doc.id}
                  onClick={() => {
                    setSelectedDoc(doc);
                    setFixApplied(false);
                  }}
                  className={`p-3 rounded-2xl border text-xs transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-slate-850 border-cyan-500/50 shadow-md shadow-cyan-950/20'
                      : 'bg-slate-950/60 border-slate-850 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <span className="font-semibold text-white line-clamp-1">
                      {doc.name}
                    </span>
                    <span
                      className={`text-[9px] px-1.5 py-0.2 rounded font-mono font-bold shrink-0 ${
                        doc.status === 'verified'
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : 'bg-amber-500/20 text-amber-400'
                      }`}
                    >
                      {doc.healthScore}%
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1 flex items-center justify-between">
                    <span>{doc.category}</span>
                    <span className="font-mono text-slate-500">{doc.fileSize}</span>
                  </p>
                  {doc.issues.length > 0 && (
                    <div className="mt-2 text-[10px] text-amber-400 flex items-center gap-1 font-medium">
                      <AlertTriangle className="w-3 h-3 shrink-0" />
                      <span className="truncate">{doc.issues[0]}</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 2 Columns: Live Document Health Inspection & Auto-Fix Workbench */}
        <div className="lg:col-span-2 p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-6">
          {/* Active Inspect Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs px-2.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                  {selectedDoc.fileType} • {selectedDoc.fileSize}
                </span>
                <span
                  className={`text-xs px-2.5 py-0.5 rounded font-mono font-bold ${
                    selectedDoc.healthScore >= 90
                      ? 'bg-emerald-500/20 text-emerald-400'
                      : 'bg-amber-500/20 text-amber-400'
                  }`}
                >
                  Health Score: {selectedDoc.healthScore}%
                </span>
              </div>
              <h2 className="text-lg sm:text-xl font-bold font-display text-white">
                {selectedDoc.name}
              </h2>
            </div>

            {/* Quick Actions */}
            <div className="flex items-center gap-2">
              {selectedDoc.issues.length > 0 && !fixApplied && (
                <button
                  onClick={handleAutoFix}
                  disabled={isProcessing}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-500 text-white text-xs font-bold shadow-lg shadow-cyan-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Wrench className="w-3.5 h-3.5" />
                  <span>{isProcessing ? 'Aligning...' : 'Fix Issues with AI'}</span>
                </button>
              )}
              {fixApplied && (
                <div className="px-3 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-semibold flex items-center gap-1.5">
                  <Check className="w-3.5 h-3.5" />
                  <span>Auto-Correction Applied</span>
                </div>
              )}
            </div>
          </div>

          {/* Health Score Visual Gauge */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex justify-between text-xs font-semibold">
              <span className="text-slate-300">DOCUMENT HEALTH METRICS</span>
              <span className="text-cyan-400 font-mono">{selectedDoc.healthScore}% Validated</span>
            </div>
            <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-700 ${
                  selectedDoc.healthScore >= 90
                    ? 'bg-emerald-400 w-[94%]'
                    : 'bg-amber-400 w-[72%]'
                }`}
              />
            </div>
            <p className="text-[11px] text-slate-400 pt-1">
              Cross-checked against MCA CIN Registry, Maharashtra DIC Database, and MIDC Plot Allotment records.
            </p>
          </div>

          {/* Field Verification Checklist */}
          <div className="space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">
              Extracted OCR Fields & Cross-Verification
            </span>
            <div className="space-y-2">
              {selectedDoc.matchedFields.map((f, idx) => (
                <div
                  key={idx}
                  className="p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs gap-3"
                >
                  <div>
                    <span className="text-slate-400 block text-[11px] font-medium">{f.field}</span>
                    <span className="text-white font-medium">{f.value}</span>
                  </div>
                  <div>
                    {f.status === 'match' ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 text-[10px] font-semibold border border-emerald-500/30">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>VERIFIED</span>
                      </span>
                    ) : f.status === 'mismatch' ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-amber-500/15 text-amber-400 text-[10px] font-semibold border border-amber-500/30">
                        <AlertTriangle className="w-3 h-3" />
                        <span>MISMATCH</span>
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-rose-500/15 text-rose-400 text-[10px] font-semibold border border-rose-500/30">
                        <XCircle className="w-3 h-3" />
                        <span>MISSING</span>
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Detected Issues & Resolution Box */}
          {selectedDoc.issues.length > 0 ? (
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-2">
              <span className="text-xs font-bold text-amber-300 uppercase flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4" />
                <span>Detected Inconsistencies Requiring Attention</span>
              </span>
              <ul className="list-disc list-inside text-xs text-amber-200/90 space-y-1">
                {selectedDoc.issues.map((issue, i) => (
                  <li key={i}>{issue}</li>
                ))}
              </ul>
              <div className="pt-2">
                <button
                  onClick={handleAutoFix}
                  className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors"
                >
                  <Wrench className="w-3.5 h-3.5" />
                  <span>Apply AI Rectification Overlay</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-xs text-emerald-300 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                All statutory fields are compliant. This document is certified for government submission.
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
