import React, { useState } from 'react';
import {
  Building2,
  MapPin,
  Users,
  IndianRupee,
  Calendar,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  Layers,
  Award,
  ArrowRight,
  RefreshCw,
  PlusCircle
} from 'lucide-react';
import { BusinessProfile, Language } from '../types';
import { TRANSLATIONS } from '../data/demoData';

interface BusinessProfileViewProps {
  business: BusinessProfile;
  onUpdateBusiness: (newBiz: BusinessProfile) => void;
  language: Language;
}

export const BusinessProfileView: React.FC<BusinessProfileViewProps> = ({
  business,
  onUpdateBusiness,
  language
}) => {
  const [showWizard, setShowWizard] = useState(false);
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    type: 'Private Limited Company',
    industry: 'Renewable Energy & Clean Tech',
    location: 'Pune Industrial Belt',
    state: 'Maharashtra',
    size: 'Medium' as 'Micro' | 'Small' | 'Medium' | 'Large Enterprise',
    investment: '₹10.50 Crores',
    employees: 120,
    activities: 'Solar module assembly, energy storage integration',
    products: 'Solar PV Modules, Li-ion Batteries',
    startDate: '2024-01-15'
  });

  const t = TRANSLATIONS[language];

  const handleFinishWizard = (e: React.FormEvent) => {
    e.preventDefault();
    const newProfile: BusinessProfile = {
      id: `biz-${Date.now()}`,
      name: formData.name || 'SolarGrid Innovations Pvt. Ltd.',
      type: formData.type,
      industry: formData.industry,
      location: formData.location,
      state: formData.state,
      size: formData.size,
      investment: formData.investment,
      employees: Number(formData.employees) || 50,
      activities: formData.activities.split(',').map((s) => s.trim()),
      products: formData.products.split(',').map((s) => s.trim()),
      startDate: formData.startDate,
      riskProfile: 'LOW',
      category: 'Green Industry (Pollution Index: 26)',
      gstin: '27AABCS9876Q1Z2',
      pan: 'AABCS9876Q'
    };

    onUpdateBusiness(newProfile);
    setShowWizard(false);
    setStep(1);
  };

  return (
    <div className="space-y-8 pb-16 animate-in fade-in duration-200" id="orvixi-business-profile-view">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/80 border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 font-mono">
              AI BUSINESS DOSSIER
            </span>
            <span className="text-xs text-slate-400 font-mono">ID: {business?.id || 'biz-01'}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-display text-white">
            {business?.name || 'GreenTech Manufacturing Pvt. Ltd.'}
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            AI-generated compliance architecture, corporate metadata, and statutory profile
          </p>
        </div>

        <button
          onClick={() => setShowWizard(!showWizard)}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-500 text-white text-xs font-semibold shadow-lg shadow-cyan-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-2 shrink-0 cursor-pointer"
        >
          <PlusCircle className="w-4 h-4" />
          <span>{showWizard ? 'Close Onboarding Wizard' : 'Onboard New Business'}</span>
        </button>
      </div>

      {/* MULTI-STEP ONBOARDING WIZARD */}
      {showWizard && (
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border-2 border-cyan-500/40 shadow-2xl animate-in zoom-in-95 duration-150">
          <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-6">
            <div>
              <h2 className="text-lg font-bold text-white font-display">
                Intelligent Business Onboarding Wizard
              </h2>
              <p className="text-xs text-slate-400">
                Step {step} of 3: Provide operational details to auto-generate approval maps & subsidies
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className={`w-3 h-3 rounded-full ${step >= 1 ? 'bg-cyan-400' : 'bg-slate-800'}`} />
              <span className={`w-3 h-3 rounded-full ${step >= 2 ? 'bg-cyan-400' : 'bg-slate-800'}`} />
              <span className={`w-3 h-3 rounded-full ${step >= 3 ? 'bg-cyan-400' : 'bg-slate-800'}`} />
            </div>
          </div>

          <form onSubmit={handleFinishWizard} className="space-y-6">
            {step === 1 && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Business Legal Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Apex Bio-Tech Industries Pvt. Ltd."
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Constitution Type
                    </label>
                    <select
                      value={formData.type}
                      onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-cyan-400"
                    >
                      <option>Private Limited Company</option>
                      <option>Limited Liability Partnership (LLP)</option>
                      <option>Public Limited Company</option>
                      <option>Partnership Firm</option>
                      <option>Sole Proprietorship</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Industry Vertical
                    </label>
                    <select
                      value={formData.industry}
                      onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-cyan-400"
                    >
                      <option>Renewable Energy & Clean Tech</option>
                      <option>Agri-Tech & Food Processing</option>
                      <option>Automotive & Electric Mobility</option>
                      <option>Waste Management & Circular Economy</option>
                      <option>Pharmaceuticals & Healthcare</option>
                      <option>Electronics System Design & Manufacturing</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Operating State
                    </label>
                    <select
                      value={formData.state}
                      onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-cyan-400"
                    >
                      <option>Maharashtra</option>
                      <option>Gujarat</option>
                      <option>Karnataka</option>
                      <option>Tamil Nadu</option>
                      <option>Delhi NCR</option>
                      <option>Telangana</option>
                    </select>
                  </div>
                </div>

                <div className="flex justify-end pt-4">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors"
                  >
                    <span>Next: Scale & Investment</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Enterprise Classification
                    </label>
                    <select
                      value={formData.size}
                      onChange={(e) => setFormData({ ...formData, size: e.target.value as any })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-cyan-400"
                    >
                      <option>Micro (Inv &lt; ₹1 Cr)</option>
                      <option>Small (Inv ₹1 Cr - ₹10 Cr)</option>
                      <option>Medium (Inv ₹10 Cr - ₹50 Cr)</option>
                      <option>Large Enterprise (Inv &gt; ₹50 Cr)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Total Capital Investment
                    </label>
                    <input
                      type="text"
                      value={formData.investment}
                      onChange={(e) => setFormData({ ...formData, investment: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      Employee Count
                    </label>
                    <input
                      type="number"
                      value={formData.employees}
                      onChange={(e) => setFormData({ ...formData, employees: Number(e.target.value) })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Factory / Facility Physical Location
                  </label>
                  <input
                    type="text"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div className="flex justify-between pt-4">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={() => setStep(3)}
                    className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors"
                  >
                    <span>Next: Operations & Activities</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Key Manufacturing / Business Activities (Comma separated)
                  </label>
                  <textarea
                    rows={2}
                    value={formData.activities}
                    onChange={(e) => setFormData({ ...formData, activities: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Products or Services Produced
                  </label>
                  <input
                    type="text"
                    value={formData.products}
                    onChange={(e) => setFormData({ ...formData, products: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div className="p-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-xs text-cyan-300 flex items-start gap-2">
                  <Sparkles className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <p>
                    ORVIXI AI will synthesize these parameters against Central and State gazettes to generate your custom Approval Navigator, Compliance Calendar, and Government Subsidies.
                  </p>
                </div>

                <div className="flex justify-between pt-4">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 via-indigo-500 to-emerald-400 text-white font-bold text-xs shadow-xl shadow-cyan-500/30 flex items-center gap-2"
                  >
                    <Sparkles className="w-4 h-4" />
                    <span>Generate AI Business Profile</span>
                  </button>
                </div>
              </div>
            )}
          </form>
        </div>
      )}

      {/* ACTIVE PROFILE OVERVIEW */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Card */}
        <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Statutory Details
            </span>
            <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono">
              Verified
            </span>
          </div>

          <div className="space-y-3.5 text-xs sm:text-sm">
            <div className="flex justify-between">
              <span className="text-slate-400">Constitution:</span>
              <span className="text-white font-medium">{business.type}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Industry:</span>
              <span className="text-white font-medium text-right max-w-[180px]">{business.industry}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Location:</span>
              <span className="text-white font-medium">{business.location}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">State:</span>
              <span className="text-white font-medium">{business.state}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Capital Investment:</span>
              <span className="text-emerald-400 font-mono font-bold">{business.investment}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Employees:</span>
              <span className="text-white font-medium">{business.employees} personnel</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">GSTIN:</span>
              <span className="text-cyan-400 font-mono font-semibold">{business.gstin}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">PAN:</span>
              <span className="text-cyan-400 font-mono font-semibold">{business.pan}</span>
            </div>
          </div>
        </div>

        {/* AI Risk Profile & Category */}
        <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              AI Risk & Environmental Score
            </span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono font-bold">
              RISK: {business.riskProfile}
            </span>
          </div>

          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
              <span className="text-[11px] font-bold text-cyan-400 uppercase">
                Environmental Classification
              </span>
              <p className="text-xs text-slate-200 font-medium">
                {business.category}
              </p>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Pollution Index is strictly under 30 (threshold for Orange/Red). Qualifies for fast-track 5-year CTE and simplified CTO renewal.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2">
              <span className="text-[11px] font-bold text-indigo-400 uppercase">
                Labour & Safety Profile
              </span>
              <p className="text-xs text-slate-200 font-medium">
                142 Active Employees • High Safety Compliance
              </p>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Full EPFO & ESIC employer registration verified. Licensed safety officer appointed under Section 40-B of Factories Act 1948.
              </p>
            </div>
          </div>
        </div>

        {/* Suggested Next Actions */}
        <div className="p-6 rounded-3xl bg-slate-900/80 border border-slate-800 space-y-4">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block pb-3 border-b border-slate-800">
            AI Recommendations for this Profile
          </span>

          <div className="space-y-3 text-xs">
            <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/20 space-y-1">
              <span className="font-bold text-cyan-300">1. Complete DISH Factory License</span>
              <p className="text-slate-400 text-[11px]">
                Required for 142 workers. Unlocks pending MPCB Consent to Operate.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 space-y-1">
              <span className="font-bold text-emerald-300">2. Apply for PLI Scheme Solar PV</span>
              <p className="text-slate-400 text-[11px]">
                94% eligibility match. Grants up to ₹45 Lakhs - ₹1.8 Cr.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-indigo-500/10 border border-indigo-500/20 space-y-1">
              <span className="font-bold text-indigo-300">3. Claim Electricity Duty Exemption</span>
              <p className="text-slate-400 text-[11px]">
                Under Maharashtra PSI 2019, saving ~₹14.2 Lakhs annually on HT power.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
