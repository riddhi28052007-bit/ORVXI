import React from 'react';
import {
  ArrowRight,
  Mic,
  ShieldCheck,
  Zap,
  Sparkles,
  FileCheck,
  Layers,
  Award,
  GitBranch,
  Activity,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  Building,
  Lock
} from 'lucide-react';
import { AppView, Language } from '../types';
import { TRANSLATIONS } from '../data/demoData';

interface LandingViewProps {
  onNavigate: (view: AppView) => void;
  onOpenJarvis: () => void;
  language: Language;
}

export const LandingView: React.FC<LandingViewProps> = ({
  onNavigate,
  onOpenJarvis,
  language
}) => {
  const t = TRANSLATIONS[language];

  return (
    <div className="space-y-16 py-6 pb-20 animate-in fade-in duration-300" id="orvixi-landing-view">
      {/* HERO SECTION */}
      <section className="relative overflow-hidden pt-4 pb-12 px-4 sm:px-6 lg:px-8">
        {/* Subtle Ambient Background Gradients */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-cyan-500/15 via-indigo-500/10 to-emerald-500/15 blur-[120px] rounded-full pointer-events-none" />

        <div className="max-w-5xl mx-auto text-center space-y-6 relative z-10">
          {/* Top Pill */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900/90 border border-cyan-500/30 text-xs font-semibold text-cyan-300 shadow-lg shadow-cyan-950/40">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            <span>ORVIXI AI Ecosystem • Next-Gen Business Operating System</span>
          </div>

          {/* Primary Headline */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold font-display tracking-tight text-white leading-[1.15]">
            Navigate Approvals.{' '}
            <span className="bg-gradient-to-r from-cyan-400 via-indigo-300 to-emerald-400 bg-clip-text text-transparent">
              Automate Compliance.
            </span>{' '}
            Grow Smarter.
          </h1>

          {/* Subheading */}
          <p className="max-w-3xl mx-auto text-base sm:text-lg text-slate-300 leading-relaxed">
            ORVIXI uses AI to map business approvals, validate documents, manage workflows,
            predict compliance risks, discover government support and organize your work in one
            intelligent workspace.
          </p>

          {/* Action CTAs */}
          <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-4 pt-2">
            <button
              onClick={() => onNavigate('dashboard')}
              className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 via-indigo-500 to-emerald-500 text-white font-semibold text-sm sm:text-base shadow-xl shadow-cyan-500/25 hover:shadow-cyan-500/40 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-2 cursor-pointer"
              id="landing-hero-get-started"
            >
              <span>{t.getStarted}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onNavigate('approval-mapper')}
              className="px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-700 text-slate-200 font-semibold text-sm sm:text-base hover:text-white transition-all flex items-center gap-2 cursor-pointer"
              id="landing-hero-explore"
            >
              <span>{t.explore}</span>
            </button>

            <button
              onClick={onOpenJarvis}
              className="px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-850 border border-cyan-500/40 text-cyan-300 font-semibold text-sm sm:text-base hover:text-white transition-all flex items-center gap-2 shadow-lg cursor-pointer group"
              id="landing-hero-talk-jarvis"
            >
              <Mic className="w-4 h-4 text-cyan-400 group-hover:rotate-12 transition-transform" />
              <span>{t.talkToJarvis}</span>
            </button>
          </div>

          {/* Core Philosophy Banner */}
          <div className="pt-6">
            <div className="inline-flex flex-col sm:flex-row items-center gap-2 sm:gap-4 px-4 py-2.5 rounded-2xl bg-slate-900/80 border border-slate-800 text-xs text-slate-300">
              <span className="font-bold text-cyan-400 uppercase tracking-wider">
                Core Philosophy:
              </span>
              <span className="italic text-slate-200">
                “Don’t just tell users what is required. Tell them what to do next.”
              </span>
              <div className="flex items-center gap-1.5 font-mono text-[11px] text-emerald-400">
                <span>Info</span> → <span>Intel</span> → <span>Recommend</span> → <span>Action</span>
              </div>
            </div>
          </div>
        </div>

        {/* INTERACTIVE COMMAND CENTER VISUALIZER */}
        <div className="max-w-6xl mx-auto mt-12 rounded-3xl bg-gradient-to-b from-slate-900/90 to-slate-950 border border-slate-800 p-4 sm:p-6 shadow-2xl relative">
          {/* Top Bar Indicator */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-800/80 mb-6">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-rose-500/80" />
              <div className="w-3 h-3 rounded-full bg-amber-500/80" />
              <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
              <span className="ml-2 text-xs font-mono text-slate-400">
                ORVIXI_COMMAND_CENTER // Live Neural Topology
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 font-mono">
                System Active • 87% Compliance
              </span>
            </div>
          </div>

          {/* Command Center Interconnected Bento Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Card 1: Business Profile & Approvals */}
            <div
              onClick={() => onNavigate('approval-mapper')}
              className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-cyan-500/40 transition-all cursor-pointer group hover:bg-slate-850"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Building className="w-3.5 h-3.5 text-cyan-400" />
                  Approval Navigator
                </span>
                <span className="text-xs px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-mono">
                  18 Total
                </span>
              </div>
              <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                GreenTech Manufacturing
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                11 Completed • 7 Pending • Critical path: Factory License Form 4
              </p>
              <div className="mt-4 flex items-center gap-2">
                <div className="flex-1 bg-slate-800 rounded-full h-2 overflow-hidden">
                  <div className="bg-gradient-to-r from-cyan-400 to-indigo-500 h-full w-[68%]" />
                </div>
                <span className="text-[11px] font-mono text-cyan-400 font-bold">68% Done</span>
              </div>
            </div>

            {/* Card 2: Document Health & OCR */}
            <div
              onClick={() => onNavigate('document-validator')}
              className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-indigo-500/40 transition-all cursor-pointer group hover:bg-slate-850"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <FileCheck className="w-3.5 h-3.5 text-indigo-400" />
                  Document Health
                </span>
                <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono">
                  87% Healthy
                </span>
              </div>
              <h3 className="text-sm font-bold text-white group-hover:text-indigo-300 transition-colors">
                24 of 27 Verified
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                ✓ Name match • ✓ CIN valid • ⚠ Address variation on Layout
              </p>
              <div className="mt-3 flex items-center gap-1.5 text-[11px] text-amber-400 bg-amber-500/10 p-2 rounded-xl border border-amber-500/20">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">Auto-fix overlay ready for submission</span>
              </div>
            </div>

            {/* Card 3: Government Scheme Matching */}
            <div
              onClick={() => onNavigate('government-schemes')}
              className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-emerald-500/40 transition-all cursor-pointer group hover:bg-slate-850"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Award className="w-3.5 h-3.5 text-emerald-400" />
                  Govt Incentives
                </span>
                <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono">
                  8 Matches
                </span>
              </div>
              <h3 className="text-sm font-bold text-white group-hover:text-emerald-300 transition-colors">
                Solar PV PLI (94% Match)
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Up to ₹45 Lakhs - ₹1.8 Cr • Deadline: 18 days remaining
              </p>
              <div className="mt-3 flex items-center justify-between text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 p-2 rounded-xl border border-emerald-500/20">
                <span>Potential Benefit: ₹1.45 Cr</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* Card 4: Predictive Compliance */}
            <div
              onClick={() => onNavigate('compliance')}
              className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-amber-500/40 transition-all cursor-pointer group hover:bg-slate-850"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-amber-400" />
                  Predictive Compliance
                </span>
                <span className="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono">
                  LOW RISK
                </span>
              </div>
              <h3 className="text-sm font-bold text-white group-hover:text-amber-300 transition-colors">
                Upcoming Deadlines
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Hazardous waste consent due in 14 days. ESIC wage filing in 8 days.
              </p>
              <span className="inline-block mt-3 text-[11px] text-cyan-400 font-medium">
                View Risk Timeline & Alerts →
              </span>
            </div>

            {/* Card 5: AI Detected Work */}
            <div
              onClick={() => onNavigate('my-orvixi')}
              className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-cyan-500/40 transition-all cursor-pointer group hover:bg-slate-850"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                  AI Detected Work
                </span>
                <span className="text-xs px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 font-mono">
                  3 Actions
                </span>
              </div>
              <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                What Should I Do Next?
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                1. Resolve blueprint address mismatch
                <br />
                2. Submit Factory License (Form 4)
              </p>
              <span className="inline-block mt-3 text-[11px] text-cyan-400 font-medium">
                Launch Personal AI Workspace →
              </span>
            </div>

            {/* Card 6: JARVIS AI Voice Companion */}
            <div
              onClick={onOpenJarvis}
              className="p-5 rounded-2xl bg-gradient-to-br from-indigo-950/60 to-slate-900 border border-indigo-500/30 hover:border-indigo-400 transition-all cursor-pointer group hover:scale-[1.01]"
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold text-indigo-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Mic className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                  JARVIS Voice Companion
                </span>
                <span className="text-xs px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-mono">
                  Multilingual
                </span>
              </div>
              <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                “Ask me anything in English, हिन्दी, or मराठी”
              </h3>
              <p className="text-xs text-slate-300 mt-1">
                Context-aware conversational intelligence with one-tap “Explain Simply”.
              </p>
              <div className="mt-3 flex items-center gap-2 text-xs font-semibold text-cyan-400">
                <span>Start Natural Voice Session</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* THREE CORE PILLARS */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-3 mb-10">
          <h2 className="text-2xl sm:text-3xl font-extrabold font-display text-white">
            From Idea to Action, Powered by AI
          </h2>
          <p className="text-slate-400 text-sm max-w-xl mx-auto">
            ORVIXI replaces weeks of bureaucratic confusion with proactive, automated guidance.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
              <Layers className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-white font-display">1. Think Better</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Input raw ideas into the AI Idea Lab. ORVIXI analyzes regulatory viability,
              categorizes required vs conditional approvals, and projects an actionable roadmap.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
              <GitBranch className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-white font-display">2. Plan Smarter</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Map sequential and parallel dependencies across municipal, state, and central bodies.
              Identify bottlenecks before they cause operational delays.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Zap className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-white font-display">3. Act Faster</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              AI Document Validator pre-checks uploads with OCR to catch mismatches. Proactive
              alerts answer “What Should I Do Next?” at every single step.
            </p>
          </div>
        </div>
      </section>

      {/* TRUST & SECURITY BANNER */}
      <section className="max-w-5xl mx-auto px-4">
        <div className="p-6 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Enterprise Privacy & Layered Security</h4>
              <p className="text-xs text-slate-400">
                ORVIXI uses layered security and privacy controls designed to protect user data. Strict workspace isolation.
              </p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('security')}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 hover:text-white transition-colors shrink-0"
          >
            Review Security Architecture →
          </button>
        </div>
      </section>
    </div>
  );
};
