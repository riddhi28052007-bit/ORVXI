import React, { useState } from 'react';
import {
  Search,
  Mic,
  Moon,
  Sun,
  Bell,
  Globe,
  Building2,
  Menu,
  X,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  FileText,
  HelpCircle,
  User,
  UserPlus,
  LogIn
} from 'lucide-react';
import { OrvixiLogo } from './OrvixiLogo';
import { AppView, Language, BusinessProfile, UserAccount } from '../types';
import { TRANSLATIONS, DEMO_BUSINESS } from '../data/demoData';

interface NavbarProps {
  currentView: AppView;
  onNavigate: (view: AppView) => void;
  language: Language;
  onLanguageChange: (lang: Language) => void;
  isDark?: boolean;
  onToggleTheme?: () => void;
  onOpenSearch: () => void;
  onOpenJarvis: () => void;
  activeBusiness?: BusinessProfile;
  business?: BusinessProfile;
  isDemoBusiness?: boolean;
  onToggleDemoBusiness?: () => void;
  unreadCount?: number;
  currentUser?: UserAccount;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  language,
  onLanguageChange,
  isDark,
  onToggleTheme,
  onOpenSearch,
  onOpenJarvis,
  activeBusiness,
  business,
  isDemoBusiness,
  onToggleDemoBusiness,
  unreadCount = 3,
  currentUser
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showLangMenu, setShowLangMenu] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const currentBiz = activeBusiness || business || DEMO_BUSINESS;
  const bizName = currentBiz?.name || 'GreenTech Manufacturing Pvt. Ltd.';

  const t = TRANSLATIONS[language];

  return (
    <header
      id="orvixi-main-navbar"
      className="sticky top-0 z-40 w-full backdrop-blur-xl border-b transition-colors duration-200 border-slate-800/80 bg-slate-950/80"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Left: Brand Logo & Current View */}
        <div className="flex items-center gap-6">
          <button
            onClick={() => onNavigate('landing')}
            className="flex items-center text-left transition-opacity hover:opacity-90 cursor-pointer"
            id="nav-logo-btn"
          >
            <OrvixiLogo size="md" />
          </button>

          {/* Active Business Badge */}
          <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/90 border border-slate-700/80 text-xs text-slate-300 shadow-inner">
            <Building2 className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-semibold text-white truncate max-w-[200px]">
              {bizName}
            </span>
            <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-400 font-mono border border-emerald-500/30">
              87% Score
            </span>
            {onToggleDemoBusiness && (
              <button
                onClick={onToggleDemoBusiness}
                className="ml-1 text-[10px] underline text-cyan-400 hover:text-cyan-300 transition-colors"
                title="Toggle or reset to demo data"
                id="toggle-demo-business-btn"
              >
                {isDemoBusiness ? 'Reset' : 'Switch'}
              </button>
            )}
          </div>
        </div>

        {/* Center: Global Search Trigger */}
        <div className="flex-1 max-w-md hidden md:block">
          <button
            type="button"
            onClick={onOpenSearch}
            id="global-search-trigger"
            className="w-full flex items-center justify-between px-3.5 py-2 rounded-xl bg-slate-900/90 hover:bg-slate-850 border border-slate-800 text-slate-400 text-sm transition-all hover:border-slate-700 shadow-sm cursor-pointer group"
          >
            <div className="flex items-center gap-2.5">
              <Search className="w-4 h-4 text-slate-400 group-hover:text-cyan-400 transition-colors" />
              <span className="text-slate-400 group-hover:text-slate-200 transition-colors text-xs sm:text-sm">
                {t.searchPlaceholder}
              </span>
            </div>
            <kbd className="hidden sm:inline-flex items-center gap-0.5 px-2 py-0.5 rounded bg-slate-800 border border-slate-700 text-[10px] font-mono text-slate-400">
              ⌘K
            </kbd>
          </button>
        </div>

        {/* Right Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Mobile Search Button */}
          <button
            type="button"
            onClick={onOpenSearch}
            className="md:hidden p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            id="mobile-search-btn"
            aria-label="Search"
          >
            <Search className="w-5 h-5" />
          </button>

          {/* Multilingual Selector */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowLangMenu(!showLangMenu)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-300 hover:text-white bg-slate-900/80 hover:bg-slate-800 border border-slate-800 transition-colors"
              id="language-selector-btn"
            >
              <Globe className="w-3.5 h-3.5 text-indigo-400" />
              <span className="uppercase">{language}</span>
            </button>

            {showLangMenu && (
              <div
                className="absolute right-0 mt-2 w-40 rounded-xl bg-slate-900 border border-slate-800 shadow-2xl p-1.5 z-50 animate-in fade-in zoom-in-95 duration-100"
                id="lang-dropdown"
              >
                <button
                  type="button"
                  onClick={() => {
                    onLanguageChange('en');
                    setShowLangMenu(false);
                  }}
                  className={`w-full text-left px-3 py-2 rounded-lg text-xs flex items-center justify-between transition-colors ${
                    language === 'en'
                      ? 'bg-cyan-500/20 text-cyan-300 font-semibold'
                      : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <span>English (EN)</span>
                  {language === 'en' && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onLanguageChange('hi');
                    setShowLangMenu(false);
                  }}
                  className={`w-full text-left px-3 py-2 rounded-lg text-xs flex items-center justify-between transition-colors ${
                    language === 'hi'
                      ? 'bg-cyan-500/20 text-cyan-300 font-semibold'
                      : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <span>हिन्दी (Hindi)</span>
                  {language === 'hi' && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onLanguageChange('mr');
                    setShowLangMenu(false);
                  }}
                  className={`w-full text-left px-3 py-2 rounded-lg text-xs flex items-center justify-between transition-colors ${
                    language === 'mr'
                      ? 'bg-cyan-500/20 text-cyan-300 font-semibold'
                      : 'text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <span>मराठी (Marathi)</span>
                  {language === 'mr' && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />}
                </button>
              </div>
            )}
          </div>

          {/* Theme Toggle */}
          <button
            type="button"
            onClick={onToggleTheme}
            className="p-2 rounded-lg text-slate-400 hover:text-white bg-slate-900/80 hover:bg-slate-850 border border-slate-800 transition-colors"
            title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            id="theme-toggle-btn"
          >
            {isDark ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-400" />}
          </button>

          {/* Notifications Trigger */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowNotifications(!showNotifications)}
              className="p-2 rounded-lg text-slate-400 hover:text-white bg-slate-900/80 hover:bg-slate-850 border border-slate-800 transition-colors relative"
              id="notifications-btn"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
              )}
            </button>

            {/* Notifications Dropdown */}
            {showNotifications && (
              <div
                className="absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl p-4 z-50 animate-in fade-in zoom-in-95 duration-100"
                id="notifications-drawer"
              >
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-sm text-white">Notifications & Alerts</span>
                    <span className="px-1.5 py-0.2 rounded text-[10px] bg-cyan-500/20 text-cyan-400 font-mono">
                      {unreadCount} new
                    </span>
                  </div>
                  <button
                    onClick={() => setShowNotifications(false)}
                    className="text-slate-400 hover:text-white text-xs"
                  >
                    Close
                  </button>
                </div>

                <div className="space-y-2.5 mt-3 max-h-72 overflow-y-auto pr-1">
                  <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-xs">
                    <div className="flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-semibold text-rose-300">Hazardous Waste Consent Expiry</p>
                        <p className="text-slate-400 text-[11px] mt-0.5">
                          Expires in 14 days. File Form 4 to prevent penalty under EPA 1986.
                        </p>
                        <button
                          onClick={() => {
                            onNavigate('compliance');
                            setShowNotifications(false);
                          }}
                          className="mt-1.5 text-[10px] font-semibold text-cyan-400 hover:underline"
                        >
                          Resolve in Compliance →
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs">
                    <div className="flex items-start gap-2">
                      <FileText className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-semibold text-amber-300">Factory Site Blueprint Mismatch</p>
                        <p className="text-slate-400 text-[11px] mt-0.5">
                          Address variation with MIDC deed detected. AI correction overlay ready.
                        </p>
                        <button
                          onClick={() => {
                            onNavigate('document-validator');
                            setShowNotifications(false);
                          }}
                          className="mt-1.5 text-[10px] font-semibold text-cyan-400 hover:underline"
                        >
                          Open Document Validator →
                        </button>
                      </div>
                    </div>
                  </div>

                  <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs">
                    <div className="flex items-start gap-2">
                      <Sparkles className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <div>
                        <p className="font-semibold text-emerald-300">Solar PLI Scheme Matched (94%)</p>
                        <p className="text-slate-400 text-[11px] mt-0.5">
                          High eligibility verified for ₹45L grant incentive. 18 days left.
                        </p>
                        <button
                          onClick={() => {
                            onNavigate('government-schemes');
                            setShowNotifications(false);
                          }}
                          className="mt-1.5 text-[10px] font-semibold text-cyan-400 hover:underline"
                        >
                          View Scheme Application →
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Individual Portal / User Sign In Trigger */}
          <button
            type="button"
            onClick={() => onNavigate('auth-portal')}
            id="individual-portal-btn"
            className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 text-xs font-semibold transition-all cursor-pointer shrink-0"
            title="Individual Person Portal & Workflows"
          >
            {currentUser?.avatarUrl ? (
              <img
                src={currentUser.avatarUrl}
                alt={currentUser.fullName}
                className="w-5 h-5 rounded-full object-cover border border-cyan-400"
              />
            ) : (
              <User className="w-4 h-4 text-cyan-400" />
            )}
            <span className="hidden sm:inline font-mono">
              {currentUser?.isLoggedIn ? currentUser.fullName.split(' ')[0] : 'Sign In'}
            </span>
          </button>

          {/* Persistent "TALK TO ORVIXI" Action Button */}
          <button
            type="button"
            onClick={onOpenJarvis}
            id="persistent-talk-to-jarvis-btn"
            className="flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold tracking-wide bg-gradient-to-r from-cyan-500 via-indigo-500 to-emerald-400 text-white shadow-lg shadow-cyan-500/20 hover:shadow-cyan-500/40 hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer group"
          >
            <div className="relative flex items-center justify-center">
              <span className="absolute w-3 h-3 rounded-full bg-white/40 animate-ping" />
              <Mic className="w-4 h-4 text-white group-hover:rotate-12 transition-transform" />
            </div>
            <span className="hidden sm:inline font-display">{t.talkToJarvis}</span>
            <span className="sm:hidden font-display">JARVIS</span>
          </button>

          {/* Mobile Menu Button */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg text-slate-400 hover:text-white bg-slate-900 border border-slate-800"
            id="mobile-nav-toggle-btn"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-800 bg-slate-950 px-4 py-4 space-y-2" id="mobile-menu-drawer">
          <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-semibold text-white">{bizName}</span>
            </div>
            {onToggleDemoBusiness && (
              <button
                onClick={() => {
                  onToggleDemoBusiness();
                  setMobileMenuOpen(false);
                }}
                className="text-[11px] px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-400 font-mono"
              >
                {isDemoBusiness ? 'Reset Demo' : 'Switch'}
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              onClick={() => {
                onNavigate('dashboard');
                setMobileMenuOpen(false);
              }}
              className={`p-2.5 rounded-lg text-left font-medium ${
                currentView === 'dashboard' ? 'bg-cyan-500/20 text-cyan-400 font-bold' : 'text-slate-300 bg-slate-900'
              }`}
            >
              Dashboard
            </button>
            <button
              onClick={() => {
                onNavigate('approval-mapper');
                setMobileMenuOpen(false);
              }}
              className={`p-2.5 rounded-lg text-left font-medium ${
                currentView === 'approval-mapper' ? 'bg-cyan-500/20 text-cyan-400 font-bold' : 'text-slate-300 bg-slate-900'
              }`}
            >
              Approval Mapper
            </button>
            <button
              onClick={() => {
                onNavigate('document-validator');
                setMobileMenuOpen(false);
              }}
              className={`p-2.5 rounded-lg text-left font-medium ${
                currentView === 'document-validator' ? 'bg-cyan-500/20 text-cyan-400 font-bold' : 'text-slate-300 bg-slate-900'
              }`}
            >
              Document Validator
            </button>
            <button
              onClick={() => {
                onNavigate('approval-workflow');
                setMobileMenuOpen(false);
              }}
              className={`p-2.5 rounded-lg text-left font-medium ${
                currentView === 'approval-workflow' ? 'bg-cyan-500/20 text-cyan-400 font-bold' : 'text-slate-300 bg-slate-900'
              }`}
            >
              Approval Workflow
            </button>
            <button
              onClick={() => {
                onNavigate('compliance');
                setMobileMenuOpen(false);
              }}
              className={`p-2.5 rounded-lg text-left font-medium ${
                currentView === 'compliance' ? 'bg-cyan-500/20 text-cyan-400 font-bold' : 'text-slate-300 bg-slate-900'
              }`}
            >
              Compliance
            </button>
            <button
              onClick={() => {
                onNavigate('government-schemes');
                setMobileMenuOpen(false);
              }}
              className={`p-2.5 rounded-lg text-left font-medium ${
                currentView === 'government-schemes' ? 'bg-cyan-500/20 text-cyan-400 font-bold' : 'text-slate-300 bg-slate-900'
              }`}
            >
              Govt Schemes
            </button>
            <button
              onClick={() => {
                onNavigate('my-orvixi');
                setMobileMenuOpen(false);
              }}
              className={`p-2.5 rounded-lg text-left font-medium ${
                currentView === 'my-orvixi' ? 'bg-cyan-500/20 text-cyan-400 font-bold' : 'text-slate-300 bg-slate-900'
              }`}
            >
              My ORVIXI
            </button>
            <button
              onClick={() => {
                onNavigate('idea-lab');
                setMobileMenuOpen(false);
              }}
              className={`p-2.5 rounded-lg text-left font-medium ${
                currentView === 'idea-lab' ? 'bg-cyan-500/20 text-cyan-400 font-bold' : 'text-slate-300 bg-slate-900'
              }`}
            >
              AI Idea Lab
            </button>
            <button
              onClick={() => {
                onNavigate('jarvis');
                setMobileMenuOpen(false);
              }}
              className={`p-2.5 rounded-lg text-left font-medium ${
                currentView === 'jarvis' ? 'bg-cyan-500/20 text-cyan-400 font-bold' : 'text-slate-300 bg-slate-900'
              }`}
            >
              JARVIS AI
            </button>
            <button
              onClick={() => {
                onNavigate('reports');
                setMobileMenuOpen(false);
              }}
              className={`p-2.5 rounded-lg text-left font-medium ${
                currentView === 'reports' ? 'bg-cyan-500/20 text-cyan-400 font-bold' : 'text-slate-300 bg-slate-900'
              }`}
            >
              Reports & Audit
            </button>
            <button
              onClick={() => {
                onNavigate('security');
                setMobileMenuOpen(false);
              }}
              className={`p-2.5 rounded-lg text-left font-medium ${
                currentView === 'security' ? 'bg-cyan-500/20 text-cyan-400 font-bold' : 'text-slate-300 bg-slate-900'
              }`}
            >
              Security Center
            </button>
            <button
              onClick={() => {
                onNavigate('landing');
                setMobileMenuOpen(false);
              }}
              className={`p-2.5 rounded-lg text-left font-medium ${
                currentView === 'landing' ? 'bg-cyan-500/20 text-cyan-400 font-bold' : 'text-slate-300 bg-slate-900'
              }`}
            >
              Landing Page
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
