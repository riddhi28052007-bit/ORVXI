import React, { useState } from 'react';
import {
  ShieldAlert,
  Calendar,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Bell,
  Check,
  RefreshCw,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  FileText
} from 'lucide-react';
import { ComplianceItem, Language, PriorityLevel } from '../types';
import { TRANSLATIONS } from '../data/demoData';

interface ComplianceEngineViewProps {
  alerts: ComplianceItem[];
  language: Language;
}

export const ComplianceEngineView: React.FC<ComplianceEngineViewProps> = ({
  alerts: initialAlerts,
  language
}) => {
  const [alerts, setAlerts] = useState<ComplianceItem[]>(initialAlerts);
  const [activeFilter, setActiveFilter] = useState<PriorityLevel | 'ALL'>('ALL');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const t = TRANSLATIONS[language];

  const handleMarkComplete = (id: string) => {
    setAlerts(alerts.filter((a) => a.id !== id));
    setToastMessage('Compliance obligation marked resolved and verified.');
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleSnooze = (id: string) => {
    setAlerts(
      alerts.map((a) => (a.id === id ? { ...a, daysRemaining: a.daysRemaining + 7 } : a))
    );
    setToastMessage('Snoozed compliance alert by 7 days.');
    setTimeout(() => setToastMessage(null), 3000);
  };

  const filtered = alerts.filter((a) => (activeFilter === 'ALL' ? true : a.risk === activeFilter));

  return (
    <div className="space-y-8 pb-16 animate-in fade-in duration-200" id="orvixi-compliance-view">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 p-4 rounded-2xl bg-emerald-500 text-slate-950 font-bold text-xs shadow-2xl flex items-center gap-2 animate-in slide-in-from-bottom-5">
          <CheckCircle2 className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/80 border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 font-mono">
              CORE FEATURE // SECTION 10 & 11
            </span>
            <span className="text-xs text-slate-400 font-mono">Statutory Horizon 2026</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-display text-white">
            Predictive Compliance & Escalation Engine
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Real-time monitoring of statutory acts, renewal triggers, expiry radars, and penalty clauses
          </p>
        </div>

        {/* Big Compliance Score Badge */}
        <div className="flex items-center gap-3 px-5 py-3 rounded-2xl bg-slate-950 border border-slate-800">
          <div className="text-right">
            <span className="text-[11px] text-slate-400 uppercase font-semibold">Regulatory Score</span>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-black font-display text-emerald-400">87%</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold font-mono">
                LOW RISK
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* AI PREDICTIVE RADAR CARD */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950/30 to-slate-900 border border-indigo-500/30 space-y-4">
        <div className="flex items-center gap-2 text-xs font-bold text-indigo-400 uppercase tracking-wider">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          <span>Proactive AI Regulatory Predictions</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-1">
            <span className="text-amber-400 font-bold">1. Document Expiry Alert</span>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              MPCB Hazardous Waste Storage Authorization expires in 14 days. Failure to renew triggers notice under Section 5 of EPA 1986.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-1">
            <span className="text-cyan-400 font-bold">2. Upstream Bottleneck Watch</span>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              Delays in DISH Factory License application will push MPCB Consent to Operate past its targeted September commissioning window.
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-1">
            <span className="text-emerald-400 font-bold">3. Financial Subsidy Preservation</span>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              Submitting GSTR-3B tax returns by 20th September locks in ₹38.4 Lakhs ITC needed for PLI grant audit verification.
            </p>
          </div>
        </div>
      </div>

      {/* RISK LEVEL FILTERS */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        <span className="text-slate-400 font-semibold mr-1">Risk Filter:</span>
        {(['ALL', 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'] as const).map((lvl) => (
          <button
            key={lvl}
            onClick={() => setActiveFilter(lvl)}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-colors shrink-0 ${
              activeFilter === lvl
                ? 'bg-cyan-500 text-slate-950 font-bold'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            {lvl} {lvl !== 'ALL' && `(${alerts.filter((a) => a.risk === lvl).length})`}
          </button>
        ))}
      </div>

      {/* COMPLIANCE ALERTS LIST */}
      <div className="space-y-4">
        {filtered.map((item) => (
          <div
            key={item.id}
            className={`p-6 rounded-3xl border transition-all space-y-4 ${
              item.risk === 'HIGH'
                ? 'bg-slate-900/90 border-rose-500/40 shadow-lg shadow-rose-950/20'
                : item.risk === 'MEDIUM'
                ? 'bg-slate-900/80 border-amber-500/30'
                : 'bg-slate-900/70 border-slate-800'
            }`}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded font-mono font-bold ${
                      item.risk === 'HIGH'
                        ? 'bg-rose-500/20 text-rose-400'
                        : item.risk === 'MEDIUM'
                        ? 'bg-amber-500/20 text-amber-400'
                        : 'bg-emerald-500/20 text-emerald-400'
                    }`}
                  >
                    RISK: {item.risk}
                  </span>
                  <span className="text-xs text-slate-400 font-medium">{item.category}</span>
                </div>
                <h3 className="text-base font-bold text-white">{item.title}</h3>
              </div>

              <div className="flex items-center gap-2 self-start sm:self-center">
                <span className="text-xs px-3 py-1 rounded-xl bg-slate-950 text-slate-300 font-mono border border-slate-800">
                  Due in: <strong>{item.daysRemaining} days</strong> ({item.dueDate})
                </span>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {item.description}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-2 border-t border-slate-800/80">
              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <span className="text-slate-500 block text-[10px] uppercase font-bold">
                  Statutory Enactment
                </span>
                <span className="text-slate-300 font-medium">{item.statutoryAct}</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                <span className="text-rose-400/90 block text-[10px] uppercase font-bold">
                  Penalty Clause on Default
                </span>
                <span className="text-slate-300 font-medium">{item.penaltyClause}</span>
              </div>
            </div>

            {/* Actions Toolbar */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <span className="text-xs text-cyan-400 font-medium flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" />
                <span>Recommended Action: {item.actionText}</span>
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleSnooze(item.id)}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
                >
                  Snooze 7 Days
                </button>
                <button
                  onClick={() => handleMarkComplete(item.id)}
                  className="px-4 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold transition-colors flex items-center gap-1.5"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Mark Resolved</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
