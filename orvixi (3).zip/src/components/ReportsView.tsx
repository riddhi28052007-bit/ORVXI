import React, { useState } from 'react';
import {
  FileText,
  Download,
  Printer,
  CheckCircle2,
  ShieldCheck,
  Building,
  Calendar,
  Layers,
  Sparkles,
  Share2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { BusinessProfile, ApprovalItem, DocumentItem, SchemeItem, Language } from '../types';
import { TRANSLATIONS } from '../data/demoData';

interface ReportsViewProps {
  business: BusinessProfile;
  approvals: ApprovalItem[];
  documents: DocumentItem[];
  schemes: SchemeItem[];
  language: Language;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  business,
  approvals,
  documents,
  schemes,
  language
}) => {
  const [selectedReport, setSelectedReport] = useState<
    'statutory_dossier' | 'licensing_audit' | 'scheme_qualification'
  >('statutory_dossier');
  const [isExporting, setIsExporting] = useState(false);

  const t = TRANSLATIONS[language];

  const handleExport = () => {
    setIsExporting(true);
    setTimeout(() => {
      setIsExporting(false);
      confetti({ particleCount: 60, spread: 60 });
      window.print();
    }, 600);
  };

  return (
    <div className="space-y-8 pb-16 animate-in fade-in duration-200" id="orvixi-reports-view">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/80 border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 font-mono">
              EXECUTIVE COMPLIANCE AUDIT
            </span>
            <span className="text-xs text-slate-400 font-mono">Export Engine v2.4</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-display text-white">
            Audit Reports & Statutory Dossiers
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Generate certified regulatory summaries for bank financing, board oversight, and government inspections
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            disabled={isExporting}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-500 text-white font-bold text-xs shadow-lg shadow-cyan-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-2 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>{isExporting ? 'Compiling Dossier...' : 'Print / Export PDF'}</span>
          </button>
        </div>
      </div>

      {/* REPORT TYPE SELECTOR */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div
          onClick={() => setSelectedReport('statutory_dossier')}
          className={`p-5 rounded-3xl border transition-all cursor-pointer ${
            selectedReport === 'statutory_dossier'
              ? 'bg-slate-900 border-cyan-500/50 shadow-lg shadow-cyan-950/30'
              : 'bg-slate-900/60 border-slate-800 hover:bg-slate-900'
          }`}
        >
          <FileText className="w-5 h-5 text-cyan-400 mb-2" />
          <h3 className="text-sm font-bold text-white">Full Statutory Dossier</h3>
          <p className="text-xs text-slate-400 mt-1">
            Comprehensive audit report covering 18 approvals, 27 documents, and risk indicators.
          </p>
        </div>

        <div
          onClick={() => setSelectedReport('licensing_audit')}
          className={`p-5 rounded-3xl border transition-all cursor-pointer ${
            selectedReport === 'licensing_audit'
              ? 'bg-slate-900 border-cyan-500/50 shadow-lg shadow-cyan-950/30'
              : 'bg-slate-900/60 border-slate-800 hover:bg-slate-900'
          }`}
        >
          <ShieldCheck className="w-5 h-5 text-emerald-400 mb-2" />
          <h3 className="text-sm font-bold text-white">Factory Licensing Audit</h3>
          <p className="text-xs text-slate-400 mt-1">
            DISH Form 4, MPCB Consent, Fire Hydrant safety and labour compliance certifications.
          </p>
        </div>

        <div
          onClick={() => setSelectedReport('scheme_qualification')}
          className={`p-5 rounded-3xl border transition-all cursor-pointer ${
            selectedReport === 'scheme_qualification'
              ? 'bg-slate-900 border-cyan-500/50 shadow-lg shadow-cyan-950/30'
              : 'bg-slate-900/60 border-slate-800 hover:bg-slate-900'
          }`}
        >
          <Sparkles className="w-5 h-5 text-indigo-400 mb-2" />
          <h3 className="text-sm font-bold text-white">Subsidy Qualification Report</h3>
          <p className="text-xs text-slate-400 mt-1">
            Documentation proving eligibility for ₹1.45 Cr across PLI, PSI 2019, and duty waivers.
          </p>
        </div>
      </div>

      {/* DOCUMENT PREVIEW PAPER */}
      <div className="p-8 sm:p-12 rounded-3xl bg-slate-950 border border-slate-800 text-slate-200 shadow-2xl max-w-4xl mx-auto space-y-8 print:p-0 print:border-none">
        {/* Document Letterhead */}
        <div className="flex flex-col sm:flex-row justify-between items-start border-b border-slate-800 pb-6 gap-4">
          <div>
            <span className="text-xs font-mono text-cyan-400 font-bold uppercase tracking-widest block mb-1">
              ORVIXI VERIFIED REGULATORY RECORD
            </span>
            <h2 className="text-2xl font-black font-display text-white">{business?.name || 'GreenTech Manufacturing Pvt. Ltd.'}</h2>
            <p className="text-xs text-slate-400 mt-1">
              {business?.location || 'Chakan, Pune'} • State: {business?.state || 'Maharashtra'} • PAN: {business?.pan || 'AABCG1234F'}
            </p>
          </div>

          <div className="text-right font-mono text-xs text-slate-400 space-y-0.5">
            <div>Verification Code: <strong>ORV-8941-MH-2026</strong></div>
            <div>Generated: {new Date().toLocaleDateString('en-GB')}</div>
            <div>Health Status: <strong className="text-emerald-400">87% VALIDATED</strong></div>
          </div>
        </div>

        {/* Executive Summary Table */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">
            1. Enterprise Statutory Footprint
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-slate-500 block text-[10px]">Industry Vertical</span>
              <span className="font-semibold text-white">{business.industry}</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-slate-500 block text-[10px]">Classification</span>
              <span className="font-semibold text-white">{business.size} Enterprise</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-slate-500 block text-[10px]">Pollution Category</span>
              <span className="font-semibold text-emerald-400">Green (Score 26)</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
              <span className="text-slate-500 block text-[10px]">Active Workforce</span>
              <span className="font-semibold text-white">{business.employees} Workers</span>
            </div>
          </div>
        </div>

        {/* Clearances Table */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">
            2. Key Regulatory Approvals Status (18 Cleared / Scheduled)
          </h3>
          <div className="rounded-2xl border border-slate-800 overflow-hidden text-xs">
            <div className="grid grid-cols-12 bg-slate-900 p-3 font-semibold text-slate-400">
              <div className="col-span-5">Approval Name</div>
              <div className="col-span-4">Authority</div>
              <div className="col-span-3 text-right">Status</div>
            </div>
            <div className="divide-y divide-slate-900">
              {approvals.slice(0, 7).map((app) => (
                <div key={app.id} className="grid grid-cols-12 p-3 items-center">
                  <div className="col-span-5 font-medium text-white">{app.name}</div>
                  <div className="col-span-4 text-slate-400">{app.authority}</div>
                  <div className="col-span-3 text-right">
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                        app.status === 'completed'
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : app.status === 'in_progress'
                          ? 'bg-cyan-500/20 text-cyan-400'
                          : 'bg-rose-500/20 text-rose-400'
                      }`}
                    >
                      {app.status.toUpperCase()}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Audit Sign-off */}
        <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row justify-between items-center text-xs text-slate-500 gap-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <span>Digital Cryptographic Audit Seal Generated by ORVIXI Intelligence Suite.</span>
          </div>
          <span className="font-mono">Document SHA-256: e8b9...7a4f</span>
        </div>
      </div>
    </div>
  );
};
