import React from 'react';

interface OrvixiLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  animated?: boolean;
  className?: string;
}

export const OrvixiLogo: React.FC<OrvixiLogoProps> = ({
  size = 'md',
  showText = true,
  animated = true,
  className = ''
}) => {
  const sizeMap = {
    sm: { box: 32, text: 'text-lg', sub: 'text-[9px]' },
    md: { box: 40, text: 'text-xl', sub: 'text-[10px]' },
    lg: { box: 56, text: 'text-2xl', sub: 'text-xs' },
    xl: { box: 72, text: 'text-4xl', sub: 'text-sm' }
  };

  const { box, text, sub } = sizeMap[size];

  return (
    <div className={`flex items-center gap-3 select-none ${className}`} id="orvixi-brand-logo">
      <div className="relative flex items-center justify-center" style={{ width: box, height: box }}>
        {/* Outer ambient glow */}
        <div className={`absolute inset-0 rounded-full bg-gradient-to-tr from-cyan-500/30 via-indigo-500/20 to-emerald-400/30 blur-md ${animated ? 'animate-pulse' : ''}`} />

        {/* Abstract Futuristic 'O' with connected neural nodes */}
        <svg
          viewBox="0 0 100 100"
          className="relative z-10 w-full h-full drop-shadow-[0_0_12px_rgba(6,182,212,0.4)]"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id="orvixiRing" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#06b6d4" />
              <stop offset="50%" stopColor="#6366f1" />
              <stop offset="100%" stopColor="#10b981" />
            </linearGradient>
            <linearGradient id="orvixiCore" x1="0%" y1="100%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#38bdf8" />
              <stop offset="100%" stopColor="#818cf8" />
            </linearGradient>
          </defs>

          {/* Outer Orbital Ring */}
          <circle
            cx="50"
            cy="50"
            r="42"
            stroke="url(#orvixiRing)"
            strokeWidth="3.5"
            strokeDasharray="18 6 12 4"
            className={animated ? 'origin-center animate-[spin_16s_linear_infinite]' : ''}
          />

          {/* Inner Orbital Node Ring */}
          <circle
            cx="50"
            cy="50"
            r="28"
            stroke="#94a3b8"
            strokeOpacity="0.3"
            strokeWidth="1.5"
            strokeDasharray="4 4"
          />

          {/* Neural Network Intersecting Vectors */}
          <path
            d="M50 16 L74 38 L68 68 L32 68 L26 38 Z"
            stroke="url(#orvixiCore)"
            strokeWidth="1.8"
            strokeOpacity="0.8"
          />
          <path
            d="M50 16 L50 84 M16 50 L84 50"
            stroke="#38bdf8"
            strokeWidth="1.2"
            strokeOpacity="0.35"
          />

          {/* Core Energy Hub (Intelligence Node) */}
          <circle cx="50" cy="50" r="7" fill="url(#orvixiRing)" />
          <circle cx="50" cy="50" r="3" fill="#ffffff" />

          {/* Satellite Data Nodes */}
          <circle cx="50" cy="16" r="3.5" fill="#06b6d4" />
          <circle cx="74" cy="38" r="3.5" fill="#6366f1" />
          <circle cx="68" cy="68" r="3.5" fill="#10b981" />
          <circle cx="32" cy="68" r="3.5" fill="#38bdf8" />
          <circle cx="26" cy="38" r="3.5" fill="#818cf8" />
        </svg>
      </div>

      {showText && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className={`font-display font-extrabold tracking-tight text-white dark:text-white ${text}`}>
              ORVIXI
            </span>
            <span className="px-1.5 py-0.5 rounded text-[9px] font-semibold tracking-wider bg-gradient-to-r from-cyan-500/20 to-indigo-500/20 border border-cyan-500/30 text-cyan-400">
              AI
            </span>
          </div>
          <span className={`text-slate-400 font-medium tracking-wide uppercase ${sub}`}>
            Think • Plan • Act
          </span>
        </div>
      )}
    </div>
  );
};
