import React, { useState } from 'react';
import {
  CheckSquare,
  Plus,
  Trash2,
  Check,
  AlertTriangle,
  Clock,
  Sparkles,
  Calendar,
  Layers,
  ArrowRight,
  Filter,
  CheckCircle2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { WorkspaceTask, BusinessProfile, Language, AppView } from '../types';
import { TRANSLATIONS } from '../data/demoData';

interface MyOrvixiWorkspaceViewProps {
  business: BusinessProfile;
  tasks: WorkspaceTask[];
  onAddTask: (task: WorkspaceTask) => void;
  onToggleTask: (id: string) => void;
  onDeleteTask: (id: string) => void;
  onNavigate: (view: AppView) => void;
  language: Language;
}

export const MyOrvixiWorkspaceView: React.FC<MyOrvixiWorkspaceViewProps> = ({
  business,
  tasks,
  onAddTask,
  onToggleTask,
  onDeleteTask,
  onNavigate,
  language
}) => {
  const [filter, setFilter] = useState<'all' | 'pending' | 'completed' | 'ai' | 'upcoming'>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskCategory, setNewTaskCategory] = useState<'DOCUMENT' | 'APPROVAL' | 'COMPLIANCE' | 'SCHEME' | 'CUSTOM'>('CUSTOM');
  const [newTaskPriority, setNewTaskPriority] = useState<'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'>('HIGH');
  const [newTaskDueDate, setNewTaskDueDate] = useState('');

  const t = TRANSLATIONS[language];

  // Helper to check if task has an upcoming deadline (<= 7 days or critical/high pending)
  const isTaskUpcoming = (task: WorkspaceTask) => {
    if (task.completed) return false;
    if (typeof task.daysLeft === 'number' && task.daysLeft <= 7) return true;
    if (task.priority === 'CRITICAL' || task.priority === 'HIGH') return true;
    if (task.deadline) {
      const diffDays = Math.ceil((new Date(task.deadline).getTime() - new Date('2026-09-07').getTime()) / (1000 * 60 * 60 * 24));
      if (!isNaN(diffDays) && diffDays <= 7) return true;
    }
    return false;
  };

  const upcomingTasks = tasks.filter(isTaskUpcoming);

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;

    const task: WorkspaceTask = {
      id: `task-${Date.now()}`,
      title: newTaskTitle,
      category: newTaskCategory,
      priority: newTaskPriority,
      deadline: newTaskDueDate || '2026-09-20',
      dueDate: newTaskDueDate || '2026-09-20',
      daysLeft: 5,
      completed: false,
      isAiDetected: false,
      source: 'user',
      reason: 'Manually scheduled execution item',
      description: 'Manually logged statutory execution item',
      actionText: 'Execute Task'
    };

    onAddTask(task);
    setNewTaskTitle('');
    setShowAddModal(false);
    confetti({ particleCount: 50, spread: 55, origin: { y: 0.7 } });
  };

  const filtered = tasks.filter((t) => {
    if (filter === 'pending') return !t.completed;
    if (filter === 'completed') return t.completed;
    if (filter === 'ai') return t.isAiDetected || t.source === 'ai_detected';
    if (filter === 'upcoming') return isTaskUpcoming(t);
    return true;
  });

  return (
    <div className="space-y-8 pb-16 animate-in fade-in duration-200" id="orvixi-my-orvixi-workspace">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/80 border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 font-mono">
              CORE FEATURE // SECTION 14
            </span>
            <span className="text-xs text-slate-400 font-mono">Autonomous Execution Engine</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-display text-white">
            MY ORVIXI Intelligence Workspace
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            AI-detected statutory tasks, team execution queues, and proactive compliance checkpoints
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Upcoming Deadlines Badge Header Notification */}
          {upcomingTasks.length > 0 && (
            <button
              onClick={() => setFilter('upcoming')}
              className="px-3 py-2 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/40 text-rose-300 text-xs font-bold font-mono flex items-center gap-2 transition-all animate-pulse cursor-pointer shadow-lg shadow-rose-950/50"
              title="Click to filter upcoming deadline tasks"
            >
              <Clock className="w-4 h-4 text-rose-400" />
              <span>{upcomingTasks.length} UPCOMING DEADLINES</span>
            </button>
          )}

          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-500 text-white text-xs font-bold shadow-lg shadow-cyan-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-1.5 cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Add Custom Task</span>
          </button>
        </div>
      </div>

      {/* UPCOMING DEADLINE HIGHLIGHT BANNER */}
      {upcomingTasks.length > 0 && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-rose-950/40 via-amber-950/20 to-slate-900 border border-rose-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-rose-500/20 border border-rose-500/40 shrink-0">
              <AlertTriangle className="w-5 h-5 text-rose-400 animate-bounce" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-white uppercase font-mono tracking-wider flex items-center gap-2">
                <span>Critical Deadlines Approaching</span>
                <span className="px-2 py-0.5 rounded-full bg-rose-500 text-slate-950 font-black text-[10px]">
                  {upcomingTasks.length} URGENT
                </span>
              </h3>
              <p className="text-xs text-slate-300 mt-0.5">
                {upcomingTasks[0]?.title} is due in{' '}
                <strong className="text-rose-400 font-mono font-bold">
                  {upcomingTasks[0]?.daysLeft ?? 4} days
                </strong>{' '}
                ({upcomingTasks[0]?.deadline || upcomingTasks[0]?.dueDate}).
              </p>
            </div>
          </div>

          <button
            onClick={() => setFilter('upcoming')}
            className="px-3.5 py-1.5 rounded-xl bg-rose-500 hover:bg-rose-400 text-slate-950 text-xs font-bold transition-all shadow-md shrink-0 cursor-pointer flex items-center gap-1"
          >
            <span>Review Urgent ({upcomingTasks.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* AI DETECTED WORK ALERT BANNER */}
      <div className="p-6 rounded-3xl bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-900 border border-cyan-500/30 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 uppercase tracking-wider">
            <Sparkles className="w-4 h-4" />
            <span>AI-Detected Work & Autonomous Suggestions</span>
          </div>
          <span className="text-xs font-mono text-cyan-300">
            {tasks.filter((t) => t.isAiDetected && !t.completed).length} Tasks Auto-Generated
          </span>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          ORVIXI continuously scans your corporate gazettes, uploaded blueprints, and municipal regulations. The following critical items were synthesized automatically to prevent business disruption:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {tasks
            .filter((t) => (t.isAiDetected || t.source === 'ai_detected') && !t.completed)
            .map((task) => (
              <div
                key={task.id}
                className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-2 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-[10px] font-mono mb-1">
                    <span className="text-cyan-400 font-bold">{task.category}</span>
                    <span className="text-rose-400 font-bold">{task.priority} PRIORITY</span>
                  </div>
                  <h4 className="text-xs font-bold text-white leading-snug">{task.title}</h4>
                  <p className="text-[11px] text-slate-400 mt-1">{task.reason || task.description}</p>
                </div>

                <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                  <span className="text-slate-500">Due: {task.deadline || task.dueDate}</span>
                  <button
                    onClick={() => onToggleTask(task.id)}
                    className="px-2 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 font-semibold transition-colors"
                  >
                    Done
                  </button>
                </div>
              </div>
            ))}
        </div>
      </div>

      {/* FILTER TABS */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-colors cursor-pointer ${
              filter === 'all'
                ? 'bg-cyan-500 text-slate-950 font-bold'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            All Tasks ({tasks.length})
          </button>

          <button
            onClick={() => setFilter('upcoming')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-colors flex items-center gap-1.5 cursor-pointer ${
              filter === 'upcoming'
                ? 'bg-rose-500 text-slate-950 font-bold'
                : 'bg-slate-900 text-rose-300 hover:text-rose-200 border border-rose-500/30'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>Upcoming Deadlines ({upcomingTasks.length})</span>
            {upcomingTasks.length > 0 && (
              <span className="w-2 h-2 rounded-full bg-rose-400 animate-ping"></span>
            )}
          </button>

          <button
            onClick={() => setFilter('pending')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-colors cursor-pointer ${
              filter === 'pending'
                ? 'bg-cyan-500 text-slate-950 font-bold'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Pending ({tasks.filter((t) => !t.completed).length})
          </button>

          <button
            onClick={() => setFilter('completed')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-colors cursor-pointer ${
              filter === 'completed'
                ? 'bg-cyan-500 text-slate-950 font-bold'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            Completed ({tasks.filter((t) => t.completed).length})
          </button>

          <button
            onClick={() => setFilter('ai')}
            className={`px-3 py-1.5 rounded-xl font-semibold transition-colors cursor-pointer ${
              filter === 'ai'
                ? 'bg-cyan-500 text-slate-950 font-bold'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            AI Detected ({tasks.filter((t) => t.isAiDetected || t.source === 'ai_detected').length})
          </button>
        </div>
      </div>

      {/* TASK LIST */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="p-8 rounded-2xl bg-slate-900/60 border border-slate-800 text-center space-y-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
            <h3 className="text-sm font-bold text-white">No tasks match this filter</h3>
            <p className="text-xs text-slate-400">All clear or select another view tab.</p>
          </div>
        ) : (
          filtered.map((task) => {
            const urgent = isTaskUpcoming(task);

            return (
              <div
                key={task.id}
                className={`p-4 sm:p-5 rounded-2xl border transition-all flex items-center justify-between gap-4 relative overflow-hidden ${
                  task.completed
                    ? 'bg-slate-900/40 border-slate-800/60 opacity-60'
                    : urgent
                    ? 'bg-slate-900/90 border-rose-500/40 shadow-md shadow-rose-950/20'
                    : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
                }`}
              >
                {/* Visual side accent bar for upcoming deadlines */}
                {urgent && !task.completed && (
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-rose-500 to-amber-500"></div>
                )}

                <div className="flex items-start gap-3.5 flex-1 min-w-0 pl-1">
                  <button
                    onClick={() => onToggleTask(task.id)}
                    className={`w-5 h-5 rounded-lg flex items-center justify-center transition-colors shrink-0 mt-0.5 cursor-pointer ${
                      task.completed
                        ? 'bg-emerald-500 text-slate-950'
                        : 'border border-slate-700 hover:border-cyan-400 bg-slate-950'
                    }`}
                  >
                    {task.completed && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                  </button>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span
                        className={`text-xs sm:text-sm font-bold ${
                          task.completed ? 'line-through text-slate-500' : 'text-white'
                        }`}
                      >
                        {task.title}
                      </span>

                      {/* UPCOMING DEADLINE BADGE */}
                      {urgent && !task.completed && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 font-mono font-bold flex items-center gap-1 animate-pulse">
                          <Clock className="w-3 h-3 text-rose-400" />
                          <span>DUE IN {task.daysLeft ?? 4} DAYS</span>
                        </span>
                      )}

                      {(task.isAiDetected || task.source === 'ai_detected') && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-mono flex items-center gap-1">
                          <Sparkles className="w-2.5 h-2.5" />
                          <span>AI DETECTED</span>
                        </span>
                      )}

                      <span
                        className={`text-[9px] px-1.5 py-0.2 rounded font-mono font-bold ${
                          task.priority === 'CRITICAL'
                            ? 'bg-rose-500/20 text-rose-400'
                            : task.priority === 'HIGH'
                            ? 'bg-amber-500/20 text-amber-400'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {task.priority}
                      </span>
                    </div>

                    <p className="text-xs text-slate-400 truncate">{task.reason || task.description}</p>

                    <div className="mt-1 flex items-center gap-3 text-[11px] text-slate-500 font-mono">
                      <span>Category: {task.category}</span>
                      <span>•</span>
                      <span className={urgent && !task.completed ? 'text-rose-400 font-bold' : ''}>
                        Due: {task.deadline || task.dueDate}
                      </span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => onDeleteTask(task.id)}
                  className="p-2 rounded-xl text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition-colors shrink-0 cursor-pointer"
                  title="Delete task"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            );
          })
        )}
      </div>

      {/* ADD TASK MODAL */}
      {showAddModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in"
          onClick={() => setShowAddModal(false)}
        >
          <div
            className="w-full max-w-md rounded-3xl bg-slate-900 border border-slate-700 p-6 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-base font-bold text-white font-display">Create Workspace Task</h3>

            <form onSubmit={handleCreateTask} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Task Title *</label>
                <input
                  type="text"
                  required
                  value={newTaskTitle}
                  onChange={(e) => setNewTaskTitle(e.target.value)}
                  placeholder="e.g. Sign DIC subsidy affidavit"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Category</label>
                  <select
                    value={newTaskCategory}
                    onChange={(e) => setNewTaskCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-400"
                  >
                    <option value="APPROVAL">APPROVAL</option>
                    <option value="DOCUMENT">DOCUMENT</option>
                    <option value="COMPLIANCE">COMPLIANCE</option>
                    <option value="SCHEME">SCHEME</option>
                    <option value="CUSTOM">CUSTOM</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-semibold mb-1">Priority</label>
                  <select
                    value={newTaskPriority}
                    onChange={(e) => setNewTaskPriority(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-400"
                  >
                    <option value="LOW">LOW</option>
                    <option value="MEDIUM">MEDIUM</option>
                    <option value="HIGH">HIGH</option>
                    <option value="CRITICAL">CRITICAL</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Due Date</label>
                <input
                  type="date"
                  value={newTaskDueDate}
                  onChange={(e) => setNewTaskDueDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold"
                >
                  Create Task
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
