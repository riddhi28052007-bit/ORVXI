import React, { useState } from 'react';
import {
  User,
  UserCheck,
  UserPlus,
  LogIn,
  LogOut,
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
  Briefcase,
  Building,
  Mail,
  Phone,
  CreditCard,
  Layers,
  Sparkles,
  Zap,
  Lock
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { UserAccount, UserRole, AppView, Language } from '../types';
import { DEMO_USERS, TRANSLATIONS } from '../data/demoData';

interface UserWorkflowPortalViewProps {
  currentUser: UserAccount;
  onUpdateUser: (user: UserAccount) => void;
  onNavigate: (view: AppView) => void;
  language: Language;
}

export const UserWorkflowPortalView: React.FC<UserWorkflowPortalViewProps> = ({
  currentUser,
  onUpdateUser,
  onNavigate,
  language
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'signin' | 'register'>('profile');

  // Sign in form state
  const [signInEmail, setSignInEmail] = useState('');
  const [signInPassword, setSignInPassword] = useState('');
  const [signInError, setSignInError] = useState('');

  // Register form state
  const [regFullName, setRegFullName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regRole, setRegRole] = useState<UserRole>('Founder / Business Owner');
  const [regDesignation, setRegDesignation] = useState('');
  const [regPanNumber, setRegPanNumber] = useState('');
  const [regAadhaar, setRegAadhaar] = useState('');
  const [regCompanyName, setRegCompanyName] = useState('GreenTech Manufacturing Pvt. Ltd.');
  const [regPrimaryWorkflow, setRegPrimaryWorkflow] = useState<'approval-mapper' | 'compliance' | 'government-schemes' | 'document-validator' | 'idea-lab'>('approval-mapper');

  const [regSuccess, setRegSuccess] = useState(false);

  const t = TRANSLATIONS[language];

  // Handle Quick Sign In with Demo Account
  const handleQuickSignIn = (demoUser: UserAccount) => {
    const updated = { ...demoUser, isLoggedIn: true };
    onUpdateUser(updated);
    setActiveTab('profile');
    confetti({ particleCount: 50, spread: 60 });
  };

  // Handle Email Sign In
  const handleSignInSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!signInEmail) {
      setSignInError('Please enter your registered email address.');
      return;
    }
    const match = DEMO_USERS.find((u) => u.email.toLowerCase() === signInEmail.toLowerCase());
    if (match) {
      const updated = { ...match, isLoggedIn: true };
      onUpdateUser(updated);
      setSignInError('');
      setActiveTab('profile');
      confetti({ particleCount: 60, spread: 70 });
    } else {
      // Create user on the fly if email not found
      const newUser: UserAccount = {
        id: `user-${Date.now()}`,
        fullName: signInEmail.split('@')[0].toUpperCase(),
        email: signInEmail,
        phone: '+91 98000 00000',
        role: 'Founder / Business Owner',
        designation: 'Individual Director',
        panNumber: 'ABCDE1234F',
        aadhaarLastFour: '9900',
        companyName: 'GreenTech Manufacturing Pvt. Ltd.',
        isLoggedIn: true,
        assignedWorkflows: [
          {
            id: `wf-${Date.now()}`,
            title: 'Individual Corporate Onboarding Workflow',
            description: 'Assigned initial compliance & clearance roadmap.',
            targetView: 'approval-mapper',
            status: 'in_progress',
            progressPercent: 50,
            pendingTasksCount: 3,
            badgeText: 'INDIVIDUAL WORKFLOW'
          }
        ]
      };
      onUpdateUser(newUser);
      setActiveTab('profile');
      confetti({ particleCount: 60, spread: 70 });
    }
  };

  // Handle Registration Submit
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!regFullName || !regEmail) return;

    const newUser: UserAccount = {
      id: `user-${Date.now()}`,
      fullName: regFullName,
      email: regEmail,
      phone: regPhone || '+91 98765 43210',
      role: regRole,
      designation: regDesignation || 'Individual Specialist',
      panNumber: regPanNumber.toUpperCase() || 'AABCG1234F',
      aadhaarLastFour: regAadhaar || '1234',
      companyName: regCompanyName || 'GreenTech Manufacturing Pvt. Ltd.',
      isLoggedIn: true,
      avatarUrl: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(regFullName)}`,
      assignedWorkflows: [
        {
          id: `wf-${Date.now()}-1`,
          title: `Primary ${regRole} Workflow Navigation`,
          description: `Customized statutory workflow configured for ${regFullName}.`,
          targetView: regPrimaryWorkflow,
          status: 'in_progress',
          progressPercent: 25,
          pendingTasksCount: 4,
          badgeText: 'PERSONAL WORKFLOW'
        },
        {
          id: `wf-${Date.now()}-2`,
          title: 'Document Health & Verification Protocol',
          description: 'Verify identity documents against MIDC and MCA registries.',
          targetView: 'document-validator',
          status: 'pending',
          progressPercent: 10,
          pendingTasksCount: 2,
          badgeText: 'IDENTITY CHECK'
        }
      ]
    };

    onUpdateUser(newUser);
    setRegSuccess(true);
    confetti({ particleCount: 80, spread: 80 });
    setTimeout(() => {
      setRegSuccess(false);
      setActiveTab('profile');
    }, 1200);
  };

  const handleSignOut = () => {
    onUpdateUser({ ...currentUser, isLoggedIn: false });
  };

  return (
    <div className="space-y-8 pb-16 animate-in fade-in duration-200" id="user-workflow-portal-view">
      {/* HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 rounded-3xl bg-slate-900/80 border border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 font-mono">
              INDIVIDUAL PERSON REGISTRATION & WORKFLOW PORTAL
            </span>
            <span className="text-xs text-slate-400 font-mono">Role-Based Access Engine</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-display text-white">
            Personal Auth & Workflow Navigator
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Register individual accounts, switch corporate roles, and navigate your assigned statutory workflows
          </p>
        </div>

        {/* Current Active Account Status */}
        <div className="flex items-center gap-3 bg-slate-950 p-3 rounded-2xl border border-slate-800">
          {currentUser.avatarUrl ? (
            <img
              src={currentUser.avatarUrl}
              alt={currentUser.fullName}
              className="w-10 h-10 rounded-full object-cover border border-cyan-500/40"
            />
          ) : (
            <div className="w-10 h-10 rounded-full bg-cyan-500/20 text-cyan-300 flex items-center justify-center font-bold text-sm border border-cyan-500/40">
              {currentUser.fullName ? currentUser.fullName.charAt(0) : 'U'}
            </div>
          )}

          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-white">{currentUser.fullName}</span>
              {currentUser.isLoggedIn ? (
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              ) : (
                <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono">
                  GUEST
                </span>
              )}
            </div>
            <span className="text-[11px] text-slate-400 block">{currentUser.role}</span>
          </div>
        </div>
      </div>

      {/* PORTAL NAVIGATION TABS */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveTab('profile')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'profile'
              ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          <User className="w-4 h-4" />
          <span>My Profile & Workflows</span>
          {currentUser.assignedWorkflows.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full bg-slate-950 text-cyan-300 font-mono text-[10px]">
              {currentUser.assignedWorkflows.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('signin')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'signin'
              ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          <LogIn className="w-4 h-4" />
          <span>Sign In / Switch Person</span>
        </button>

        <button
          onClick={() => setActiveTab('register')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer ${
            activeTab === 'register'
              ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
              : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
          }`}
        >
          <UserPlus className="w-4 h-4" />
          <span>Register New Individual</span>
        </button>
      </div>

      {/* TAB 1: MY PROFILE & ASSIGNED WORKFLOWS */}
      {activeTab === 'profile' && (
        <div className="space-y-6">
          {/* USER CARD & STATS */}
          <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
            <div className="md:col-span-2 space-y-3">
              <div className="flex items-center gap-3">
                <span className="text-xs font-mono font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {currentUser.isLoggedIn ? 'AUTHENTICATED SESSION' : 'GUEST SESSION'}
                </span>
                <span className="text-xs text-slate-400 font-mono">ID: {currentUser.id}</span>
              </div>

              <h2 className="text-2xl font-bold text-white">{currentUser.fullName}</h2>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Corporate Designation</span>
                  <span className="font-semibold text-cyan-300">{currentUser.designation}</span>
                </div>
                <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Role Permission</span>
                  <span className="font-semibold text-white">{currentUser.role}</span>
                </div>
                <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Associated Company</span>
                  <span className="font-semibold text-white truncate">{currentUser.companyName}</span>
                </div>
                <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Email</span>
                  <span className="font-mono text-slate-300 truncate">{currentUser.email}</span>
                </div>
                <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">Phone</span>
                  <span className="font-mono text-slate-300">{currentUser.phone}</span>
                </div>
                <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800">
                  <span className="text-slate-500 text-[10px] block">PAN / Aadhaar</span>
                  <span className="font-mono text-emerald-400">
                    {currentUser.panNumber} (xxxx-{currentUser.aadhaarLastFour})
                  </span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-3 text-center flex flex-col justify-center">
              <ShieldCheck className="w-8 h-8 text-cyan-400 mx-auto" />
              <h4 className="text-xs font-bold text-white">ORVIXI Digital ID Certified</h4>
              <p className="text-[11px] text-slate-400">
                Encrypted role credentials linked to GreenTech Manufacturing Pvt. Ltd.
              </p>

              {currentUser.isLoggedIn ? (
                <button
                  onClick={handleSignOut}
                  className="w-full py-2 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 text-xs font-bold border border-rose-500/30 transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out Session</span>
                </button>
              ) : (
                <button
                  onClick={() => setActiveTab('signin')}
                  className="w-full py-2 rounded-xl bg-cyan-500 text-slate-950 text-xs font-bold shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>Sign In to Account</span>
                </button>
              )}
            </div>
          </div>

          {/* ASSIGNED PERSONAL WORKFLOWS */}
          <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Layers className="w-5 h-5 text-cyan-400" />
                  <span>My Assigned Statutory Workflows</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Direct navigation paths configured for {currentUser.fullName} ({currentUser.role})
                </p>
              </div>

              <span className="text-xs font-mono px-2.5 py-1 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 font-bold">
                {currentUser.assignedWorkflows.length} ACTIVE PATHWAYS
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {currentUser.assignedWorkflows.map((wf) => (
                <div
                  key={wf.id}
                  className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4 flex flex-col justify-between hover:border-slate-700 transition-all group"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                        {wf.badgeText}
                      </span>
                      <span className="text-[11px] font-mono text-slate-400">
                        {wf.pendingTasksCount} Tasks Pending
                      </span>
                    </div>

                    <h4 className="text-sm font-bold text-white group-hover:text-cyan-300 transition-colors">
                      {wf.title}
                    </h4>

                    <p className="text-xs text-slate-400 leading-relaxed">{wf.description}</p>

                    {/* Progress bar */}
                    <div className="space-y-1 pt-1">
                      <div className="flex justify-between text-[10px] font-mono">
                        <span className="text-slate-500">Workflow Completion</span>
                        <span className="text-cyan-400 font-bold">{wf.progressPercent}%</span>
                      </div>
                      <div className="w-full h-1.5 rounded-full bg-slate-900 overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 rounded-full transition-all duration-500"
                          style={{ width: `${wf.progressPercent}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => onNavigate(wf.targetView)}
                    className="w-full py-2.5 rounded-xl bg-slate-900 hover:bg-cyan-500 hover:text-slate-950 text-cyan-400 text-xs font-bold border border-slate-800 transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <span>Navigate to {wf.targetView.replace('-', ' ').toUpperCase()}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: SIGN IN / SWITCH PERSON */}
      {activeTab === 'signin' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* EMAIL SIGN IN FORM */}
          <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
            <div className="flex items-center gap-2 text-sm font-bold text-white">
              <LogIn className="w-4 h-4 text-cyan-400" />
              <span>Individual Member Sign In</span>
            </div>

            <p className="text-xs text-slate-400">
              Sign in with your corporate email to unlock personalized workflow permissions and tasks.
            </p>

            {signInError && (
              <div className="p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-medium">
                {signInError}
              </div>
            )}

            <form onSubmit={handleSignInSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Corporate Email Address</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                  <input
                    type="email"
                    required
                    value={signInEmail}
                    onChange={(e) => setSignInEmail(e.target.value)}
                    placeholder="e.g. riddhi@greentechmfg.com"
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Passcode / Access Key</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
                  <input
                    type="password"
                    value={signInPassword}
                    onChange={(e) => setSignInPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-500 text-white font-bold text-xs shadow-lg shadow-cyan-500/20 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <LogIn className="w-4 h-4" />
                <span>Sign In & Load Workflows</span>
              </button>
            </form>
          </div>

          {/* 1-CLICK QUICK SIGN IN WITH PRE-CONFIGURED PERSONAS */}
          <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>Quick Sign In with Demo Individual Personas</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Select an individual corporate profile to test specific workflow views and role permissions:
              </p>
            </div>

            <div className="space-y-3">
              {DEMO_USERS.map((demoUser) => (
                <div
                  key={demoUser.id}
                  onClick={() => handleQuickSignIn(demoUser)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                    currentUser.id === demoUser.id && currentUser.isLoggedIn
                      ? 'bg-slate-950 border-cyan-500 text-white shadow-md'
                      : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-950'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={demoUser.avatarUrl}
                      alt={demoUser.fullName}
                      className="w-10 h-10 rounded-full object-cover border border-cyan-500/30"
                    />
                    <div>
                      <h4 className="text-xs font-bold text-white">{demoUser.fullName}</h4>
                      <p className="text-[11px] text-cyan-400">{demoUser.role}</p>
                      <span className="text-[10px] text-slate-500 block">{demoUser.email}</span>
                    </div>
                  </div>

                  <span className="text-xs font-bold px-3 py-1 rounded-xl bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                    Sign In
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: REGISTER NEW INDIVIDUAL */}
      {activeTab === 'register' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 max-w-3xl mx-auto space-y-6">
          <div className="text-center space-y-1">
            <div className="w-12 h-12 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center mx-auto mb-2 border border-cyan-500/40">
              <UserPlus className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-bold text-white">Register Individual Member Account</h2>
            <p className="text-xs text-slate-400">
              Create a personal corporate account to receive assigned statutory workflows and notifications
            </p>
          </div>

          {regSuccess && (
            <div className="p-4 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold text-center flex items-center justify-center gap-2">
              <CheckCircle2 className="w-5 h-5" />
              <span>Registration Successful! Personal Workflows Provisioned.</span>
            </div>
          )}

          <form onSubmit={handleRegisterSubmit} className="space-y-4 text-xs">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Full Legal Name *</label>
                <input
                  type="text"
                  required
                  value={regFullName}
                  onChange={(e) => setRegFullName(e.target.value)}
                  placeholder="e.g. Riddhi Deotale"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Corporate Email Address *</label>
                <input
                  type="email"
                  required
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  placeholder="riddhi@company.com"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Phone Number</label>
                <input
                  type="tel"
                  value={regPhone}
                  onChange={(e) => setRegPhone(e.target.value)}
                  placeholder="+91 98230 44109"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">PAN Number</label>
                <input
                  type="text"
                  value={regPanNumber}
                  onChange={(e) => setRegPanNumber(e.target.value)}
                  placeholder="AABCG1234F"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500 font-mono uppercase"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Aadhaar (Last 4 digits)</label>
                <input
                  type="text"
                  maxLength={4}
                  value={regAadhaar}
                  onChange={(e) => setRegAadhaar(e.target.value)}
                  placeholder="8841"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500 font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-400 font-semibold mb-1">Individual Role Designation</label>
                <select
                  value={regRole}
                  onChange={(e) => setRegRole(e.target.value as UserRole)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500"
                >
                  <option value="Founder / Business Owner">Founder / Business Owner</option>
                  <option value="Compliance Officer">Compliance Officer</option>
                  <option value="Legal Consultant">Legal Consultant</option>
                  <option value="Plant Manager">Plant Manager</option>
                  <option value="Individual Contractor">Individual Contractor</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold mb-1">Designation Title</label>
                <input
                  type="text"
                  value={regDesignation}
                  onChange={(e) => setRegDesignation(e.target.value)}
                  placeholder="e.g. Managing Director & Founder"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Primary Assigned Industrial Workflow</label>
              <select
                value={regPrimaryWorkflow}
                onChange={(e) => setRegPrimaryWorkflow(e.target.value as any)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-cyan-300 font-bold focus:outline-none focus:border-cyan-500"
              >
                <option value="approval-mapper">Approval Mapper (Statutory Clearances & Licenses)</option>
                <option value="compliance">Predictive Compliance (Statutory Expiry & Penalty Prevention)</option>
                <option value="government-schemes">Government Schemes (Subsidies & Capital Grants)</option>
                <option value="document-validator">Document Validator (OCR Health & Blueprint Checks)</option>
                <option value="idea-lab">AI Idea Lab (Business Strategy & R&D)</option>
              </select>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 via-indigo-500 to-emerald-400 text-white font-bold text-xs shadow-xl shadow-cyan-500/25 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <UserCheck className="w-4 h-4" />
                <span>Register Individual & Launch Personal Workflow</span>
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
