/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  AppView,
  Language,
  BusinessProfile,
  ApprovalItem,
  ApprovalStatus,
  DocumentItem,
  SchemeItem,
  WorkspaceTask,
  ComplianceItem,
  UserAccount
} from './types';
import {
  DEFAULT_BUSINESS_PROFILE,
  DEMO_APPROVALS,
  DEMO_DOCUMENTS,
  DEMO_SCHEMES,
  DEMO_TASKS,
  DEMO_COMPLIANCE_ITEMS,
  DEFAULT_USER
} from './data/demoData';

import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { GlobalSearchModal } from './components/GlobalSearchModal';
import { JarvisModal } from './components/JarvisModal';

import { LandingView } from './components/LandingView';
import { DashboardView } from './components/DashboardView';
import { BusinessProfileView } from './components/BusinessProfileView';
import { ApprovalMapperView } from './components/ApprovalMapperView';
import { DocumentValidatorView } from './components/DocumentValidatorView';
import { ApprovalWorkflowView } from './components/ApprovalWorkflowView';
import { ComplianceEngineView } from './components/ComplianceEngineView';
import { GovernmentSchemesView } from './components/GovernmentSchemesView';
import { MyOrvixiWorkspaceView } from './components/MyOrvixiWorkspaceView';
import { IdeaLabView } from './components/IdeaLabView';
import { ReportsView } from './components/ReportsView';
import { SettingsView } from './components/SettingsView';
import { UserWorkflowPortalView } from './components/UserWorkflowPortalView';

export default function App() {
  const [currentView, setCurrentView] = useState<AppView>('landing');
  const [language, setLanguage] = useState<Language>('en');

  // Business and operational dataset state
  const [currentUser, setCurrentUser] = useState<UserAccount>(DEFAULT_USER);
  const [business, setBusiness] = useState<BusinessProfile>(DEFAULT_BUSINESS_PROFILE);
  const [approvals, setApprovals] = useState<ApprovalItem[]>(DEMO_APPROVALS);
  const [documents, setDocuments] = useState<DocumentItem[]>(DEMO_DOCUMENTS);
  const [schemes, setSchemes] = useState<SchemeItem[]>(DEMO_SCHEMES);
  const [tasks, setTasks] = useState<WorkspaceTask[]>(DEMO_TASKS);
  const [complianceAlerts, setComplianceAlerts] = useState<ComplianceItem[]>(DEMO_COMPLIANCE_ITEMS);

  // Modals state
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isJarvisOpen, setIsJarvisOpen] = useState(false);

  // Keyboard shortcut listener: Cmd+K / Ctrl+K for Global Search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Update approval status handler
  const handleUpdateApprovalStatus = (id: string, newStatus: ApprovalStatus) => {
    setApprovals((prev) =>
      prev.map((app) => (app.id === id ? { ...app, status: newStatus } : app))
    );
  };

  // Update document handler
  const handleUpdateDocument = (newDoc: DocumentItem) => {
    setDocuments((prev) => {
      const exists = prev.some((d) => d.id === newDoc.id);
      if (exists) {
        return prev.map((d) => (d.id === newDoc.id ? newDoc : d));
      }
      return [newDoc, ...prev];
    });
  };

  // Task management handlers
  const handleAddTask = (task: WorkspaceTask) => {
    setTasks((prev) => [task, ...prev]);
  };

  const handleToggleTask = (id: string) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t))
    );
  };

  const handleDeleteTask = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  // Reset to default enterprise state
  const handleResetDemoData = () => {
    setBusiness(DEFAULT_BUSINESS_PROFILE);
    setApprovals(DEMO_APPROVALS);
    setDocuments(DEMO_DOCUMENTS);
    setSchemes(DEMO_SCHEMES);
    setTasks(DEMO_TASKS);
    setComplianceAlerts(DEMO_COMPLIANCE_ITEMS);
    setCurrentView('dashboard');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* Top Navbar */}
      <Navbar
        currentView={currentView}
        onNavigate={setCurrentView}
        language={language}
        onLanguageChange={setLanguage}
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenJarvis={() => setIsJarvisOpen(true)}
        business={business}
        currentUser={currentUser}
      />

      {/* Main Workspace Body */}
      {currentView === 'landing' ? (
        <main className="flex-1">
          <LandingView
            onEnterApp={() => setCurrentView('dashboard')}
            onOpenJarvis={() => setIsJarvisOpen(true)}
            language={language}
          />
        </main>
      ) : (
        <div className="flex-1 flex max-w-[1600px] w-full mx-auto px-3 sm:px-6 lg:px-8 py-6 gap-6">
          {/* Persistent Desktop Sidebar */}
          <Sidebar
            currentView={currentView}
            onNavigate={setCurrentView}
            language={language}
            onOpenJarvis={() => setIsJarvisOpen(true)}
          />

          {/* Active View Container */}
          <main className="flex-1 min-w-0">
            {currentView === 'dashboard' && (
              <DashboardView
                business={business}
                approvals={approvals}
                documents={documents}
                schemes={schemes}
                tasks={tasks}
                complianceAlerts={complianceAlerts}
                onNavigate={setCurrentView}
                onOpenJarvis={() => setIsJarvisOpen(true)}
                language={language}
              />
            )}

            {currentView === 'business-profile' && (
              <BusinessProfileView
                business={business}
                onUpdateBusiness={(newBiz) => {
                  setBusiness(newBiz);
                  setCurrentView('dashboard');
                }}
                language={language}
              />
            )}

            {currentView === 'approval-mapper' && (
              <ApprovalMapperView
                approvals={approvals}
                onUpdateApprovalStatus={handleUpdateApprovalStatus}
                language={language}
              />
            )}

            {currentView === 'document-validator' && (
              <DocumentValidatorView
                documents={documents}
                onUpdateDocument={handleUpdateDocument}
                language={language}
              />
            )}

            {currentView === 'approval-workflow' && (
              <ApprovalWorkflowView approvals={approvals} language={language} />
            )}

            {currentView === 'compliance' && (
              <ComplianceEngineView alerts={complianceAlerts} language={language} />
            )}

            {currentView === 'government-schemes' && (
              <GovernmentSchemesView schemes={schemes} language={language} />
            )}

            {currentView === 'my-orvixi' && (
              <MyOrvixiWorkspaceView
                business={business}
                tasks={tasks}
                onAddTask={handleAddTask}
                onToggleTask={handleToggleTask}
                onDeleteTask={handleDeleteTask}
                onNavigate={setCurrentView}
                language={language}
              />
            )}

            {currentView === 'auth-portal' && (
              <UserWorkflowPortalView
                currentUser={currentUser}
                onUpdateUser={(updated) => setCurrentUser(updated)}
                onNavigate={setCurrentView}
                language={language}
              />
            )}

            {currentView === 'idea-lab' && <IdeaLabView language={language} />}

            {currentView === 'reports' && (
              <ReportsView
                business={business}
                approvals={approvals}
                documents={documents}
                schemes={schemes}
                language={language}
              />
            )}

            {currentView === 'settings' && (
              <SettingsView
                language={language}
                onLanguageChange={setLanguage}
                business={business}
                onResetDemoData={handleResetDemoData}
              />
            )}
          </main>
        </div>
      )}

      {/* Global Search Modal (Cmd+K) */}
      <GlobalSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onNavigate={(view) => {
          setCurrentView(view);
          setIsSearchOpen(false);
        }}
        approvals={approvals}
        schemes={schemes}
        language={language}
      />

      {/* Floating JARVIS Voice AI Trigger Button */}
      {currentView !== 'landing' && (
        <button
          onClick={() => setIsJarvisOpen(true)}
          className="fixed bottom-6 right-6 z-40 p-3.5 rounded-full bg-gradient-to-r from-cyan-500 via-indigo-500 to-emerald-400 text-white shadow-2xl shadow-cyan-500/40 hover:scale-105 active:scale-95 transition-all flex items-center gap-2 group cursor-pointer border border-cyan-300/40"
          title="Open ORVIXI JARVIS Voice AI"
        >
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-white"></span>
          </span>
          <span className="text-xs font-bold font-display tracking-wider hidden sm:inline pr-1">
            JARVIS AI
          </span>
        </button>
      )}

      {/* JARVIS Intelligent Voice AI Modal */}
      <JarvisModal
        isOpen={isJarvisOpen}
        onClose={() => setIsJarvisOpen(false)}
        business={business}
        approvals={approvals}
        documents={documents}
        schemes={schemes}
        language={language}
        onLanguageChange={setLanguage}
      />
    </div>
  );
}

