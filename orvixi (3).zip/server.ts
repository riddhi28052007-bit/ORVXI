import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Lazy GoogleGenAI client helper
let genAiClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  if (!process.env.GEMINI_API_KEY) {
    return null;
  }
  if (!genAiClient) {
    genAiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }
  return genAiClient;
}

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'ORVIXI Intelligence Backend',
    geminiConfigured: Boolean(process.env.GEMINI_API_KEY),
    timestamp: new Date().toISOString()
  });
});

// AI Chat endpoint for JARVIS
app.post('/api/gemini/chat', async (req, res) => {
  const { message, context, language = 'en', history = [] } = req.body;
  const ai = getGenAI();

  if (ai) {
    try {
      const systemInstruction = `You are ORVIXI (JARVIS-inspired AI business and government companion).
Tagline: "Think Better. Plan Smarter. Act Faster. From Idea to Action, Powered by AI."
Personality: Intelligent, calm, authoritative yet deeply helpful, proactive, and concise.
Language requested: ${language} (en = English, hi = Hindi, mr = Marathi).
If Hindi is requested, write in clean, friendly Devanagari script or conversational Hinglish if asked.
If Marathi is requested, write in clean, polite Marathi Devanagari.
Current workspace context: ${JSON.stringify(context || {})}
Format output with clear scannable points, bold highlights, and direct next best actions.
Always provide proactive, actionable recommendations (What to do, Why, When, Risk, How).`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: [
          { role: 'user', parts: [{ text: `${systemInstruction}\n\nUser: ${message}` }] }
        ]
      });

      return res.json({
        reply: response.text || "I have analyzed your request and updated your workspace intelligence.",
        source: 'gemini'
      });
    } catch (err: any) {
      console.warn('Gemini API call failed, falling back to local intelligence engine:', err?.message);
    }
  }

  // Fallback intelligent contextual response
  const lowerMsg = (message || '').toLowerCase();
  let fallbackReply = '';

  if (language === 'hi') {
    if (lowerMsg.includes('approval') || lowerMsg.includes('पेंडिंग')) {
      fallbackReply = `नमस्ते। आपके GreenTech Manufacturing व्यवसाय के लिए 18 में से 7 approvals अभी pending हैं।\n\n📌 **Next Best Action:** Factory License (DIC / Directorate of Industrial Safety) को पहले पूरा करें, क्योंकि Pollution Consent (MPCB) और Fire NOC इस पर निर्भर हैं।`;
    } else if (lowerMsg.includes('scheme') || lowerMsg.includes('योजना')) {
      fallbackReply = `आपके व्यवसाय के लिए 8 Government Schemes मैच हुई हैं! सबसे महत्वपूर्ण: **PLI Scheme for Renewable Energy (94% Match)** जिसमें ₹45 लाख तक का पूंजीगत प्रोत्साहन उपलब्ध है।`;
    } else {
      fallbackReply = `ORVIXI JARVIS तैयार है। आपकी वर्तमान compliance 87% है और 3 कार्य ध्यान मांग रहे हैं। बताएँ मैं किस approval, document या सरकारी योजना में आपकी मदद करूँ?`;
    }
  } else if (language === 'mr') {
    if (lowerMsg.includes('approval') || lowerMsg.includes('मंजूरी')) {
      fallbackReply = `नमस्कार. आपल्या व्यवसायासाठी 18 पैकी 7 मंजुऱ्या प्रलंबित आहेत. सर्वात आधी **Factory License** पूर्ण करा कारण प्रदूषण नियंत्रण आणि फायर एनओसी यावर अवलंबून आहेत.`;
    } else {
      fallbackReply = `ORVIXI JARVIS सक्रिय आहे. आपली व्यवसाय अनुपालन स्थिती (Compliance) 87% आहे. कागदपत्रे पडताळणी किंवा सरकारी योजनांबद्दल विचारा.`;
    }
  } else {
    if (lowerMsg.includes('approval') || lowerMsg.includes('pending')) {
      fallbackReply = `You have **7 pending approvals** out of 18 total. \n\n🎯 **Immediate Priority:** Complete the **Factory License Renewal** with the Directorate of Industrial Safety. Two downstream approvals (**MPCB Consent to Operate** and **Fire Safety NOC**) are currently blocked waiting on this.`;
    } else if (lowerMsg.includes('document') || lowerMsg.includes('missing') || lowerMsg.includes('health')) {
      fallbackReply = `Document Health is at **87%** (24 of 27 documents verified).\n\n⚠️ **Attention Required:**\n1. Factory Site Plan (Address mismatch detected with DIC registration)\n2. Hazardous Waste Consent (Expiry within 14 days)\n\nWould you like me to open the AI Document Validator to resolve these?`;
    } else if (lowerMsg.includes('scheme') || lowerMsg.includes('subsidy') || lowerMsg.includes('grant')) {
      fallbackReply = `We matched **8 Government Schemes** for GreenTech Manufacturing!\n\nTop Pick: **Production Linked Incentive (PLI) for Solar Components** (94% eligibility, up to ₹45 Lakhs). Deadline is in 18 days.`;
    } else if (lowerMsg.includes('what should i do next') || lowerMsg.includes('next')) {
      fallbackReply = `Here is your **Next Best Action**:\n\n1. **Resolve Address Mismatch** on Factory Site Layout (takes ~5 mins via Document Validator).\n2. **Submit Factory License Application** to unblock MPCB clearance.\n3. **Claim Maharashtra Industrial Subsidy (PSI 2019)** before the portal cutoff.`;
    } else {
      fallbackReply = `ORVIXI JARVIS is standing by. Your business **GreenTech Manufacturing** has an **87% compliance score** with **3 AI-detected priority tasks**.\n\nHow may I direct our execution: Approvals, Document OCR, Compliance Deadlines, or Government Scheme Applications?`;
    }
  }

  res.json({
    reply: fallbackReply,
    source: 'orvixi-core'
  });
});

// Explain Simply endpoint
app.post('/api/gemini/explain-simply', async (req, res) => {
  const { text, language = 'en' } = req.body;
  const ai = getGenAI();

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: [
          {
            role: 'user',
            parts: [
              {
                text: `You are ORVIXI's "Explain Simply" engine. Simplify the following government/legal/compliance terminology into crystal clear, plain language that anyone can easily understand.
Language: ${language}
Target text: "${text}"
Format:
- 1 concise summary sentence
- "What it means for you"
- "Action to take"`
              }
            ]
          }
        ]
      });
      return res.json({ explanation: response.text });
    } catch (e) {
      console.warn('Explain simply fallback used');
    }
  }

  // Fallback simple explanations
  if (language === 'hi') {
    res.json({
      explanation: `सरल शब्दों में: इसका मतलब है कि आपको अपने कारखाने को चलाने से पहले सरकार से पर्यावरण और सुरक्षा की पूर्व अनुमति लेनी होगी। अगर आप ऐसा नहीं करते हैं, तो काम रुक सकता है। तुरंत आवश्यक कागजात अपलोड करके आवेदन दर्ज करें।`
    });
  } else if (language === 'mr') {
    res.json({
      explanation: `सोप्या भाषेत: याचा अर्थ असा आहे की कंपनी सुरू करण्यापूर्वी आपल्याला स्थानिक प्राधिकरणाकडून पर्यावरण आणि सुरक्षिततेची अधिकृत मान्यता घेणे बंधनकारक आहे. विलंब टाळण्यासाठी आवश्यक कागदपत्रे जोडून तातडीने अर्ज करा.`
    });
  } else {
    res.json({
      explanation: `In Plain English: This requirement means your manufacturing plant must have pre-approved state environmental and occupational safety clearance before full operation begins. Delaying this risks regulatory stop-work orders. Action: Upload your site inspection certificate to complete this step.`
    });
  }
});

// AI Idea Improvisation endpoint
app.post('/api/gemini/improve-idea', async (req, res) => {
  const { idea, industry, location } = req.body;
  const ai = getGenAI();

  if (ai) {
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: [
          {
            role: 'user',
            parts: [
              {
                text: `You are ORVIXI's AI Idea Lab & Improvisation Engine.
User Input: "${idea}"
Industry: "${industry || 'General'}"
Location: "${location || 'India'}"

Transform this raw idea into a comprehensive, high-impact venture concept. Return clean JSON with:
{
  "title": "Refined Name",
  "tagline": "Short compelling punchline",
  "problem": "Clear problem statement",
  "solution": "Innovative AI-enabled solution",
  "targetUsers": ["User group 1", "User group 2"],
  "keyFeatures": ["Feature 1", "Feature 2", "Feature 3", "Feature 4"],
  "businessModel": "Monetization and sustainability structure",
  "requiredApprovals": ["Approval 1", "Approval 2", "Approval 3"],
  "governmentSchemes": ["Scheme 1 with potential grant", "Scheme 2"],
  "roadmap": ["Month 1-2: MVP", "Month 3-4: Pilot", "Month 5-6: Scale"],
  "riskMitigation": "Key risk and how to handle it"
}`
              }
            ]
          }
        ]
      });

      const text = response.text || '';
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return res.json(JSON.parse(jsonMatch[0]));
      }
    } catch (e) {
      console.warn('Idea engine fallback used');
    }
  }

  // Fallback enriched idea
  res.json({
    title: idea ? `${idea.trim()} Intelligence Platform` : "Circular Bio-Waste Logistics Network",
    tagline: "AI-Optimized Aggregation, Processing & Regulatory Compliance",
    problem: "Fragmented supply chains, non-standardized disposal practices, and complex municipal regulatory approvals cause 40%+ resource leakage.",
    solution: "A closed-loop digital coordination platform with IoT-verified tracking, automated environmental manifest filings, and dynamic buyback pricing.",
    targetUsers: ["Industrial manufacturing facilities", "Municipal municipal corporations", "Authorized recyclers & re-processors"],
    keyFeatures: [
      "Automated State Pollution Control Board (SPCB) Form-10 manifests",
      "Dynamic truck routing and weight-sensor verification",
      "Carbon credit generation and verified audit certificates",
      "Real-time marketplace connecting bulk producers to certified recyclers"
    ],
    businessModel: "Commission on secondary materials marketplace + B2B SaaS subscription for automated regulatory compliance reporting.",
    requiredApprovals: [
      "State Pollution Control Board Consent (CTO & CTE)",
      "Hazardous & Other Wastes Authorization (Rule 6)",
      "Municipal Bulk Waste Generator Registration",
      "GST & Factory Inspectorate Clearance"
    ],
    governmentSchemes: [
      "Swachh Bharat Mission 2.0 Urban Grant (Up to ₹50 Lakhs)",
      "MSME Credit Guarantee Scheme (CGTMSE)",
      "Startup India Seed Fund Scheme (SISFS)"
    ],
    roadmap: [
      "Month 1-2: MVP platform development & pilot test with 5 industrial units",
      "Month 3-4: Integration with SPCB e-manifest portal & sensor telemetry",
      "Month 5-6: Commercial rollout across Maharashtra industrial belts"
    ],
    riskMitigation: "Strict digital chain-of-custody signatures prevent compliance liabilities."
  });
});

// Vite integration
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ORVIXI Core Server running on port ${PORT}`);
  });
}

startServer();
